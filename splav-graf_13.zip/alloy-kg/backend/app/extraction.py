"""Извлечение куска графа знаний из ОДНОГО документа при загрузке:
материал + процесс + условия (числовые параметры) + география + временной
диапазон + команда/авторы (если упомянуты) -> сущности и связи, которые
затем добавляются в общий кумулятивный граф (db.upsert_entity/link_doc_entity/
add_relation/add_constraint).

Два слоя, оба реально работают и дополняют друг друга:
  1. Словарный (synonyms.py) — надёжный, мультиязычный, детерминированный,
     но ограничен тем, что явно занесено в словарь.
  2. LLM (если есть ключ) — ловит термины и связи вне словаря, авторов/команды,
     нормализует их в русские канонические имена (единый граф вне зависимости
     от языка документа). Без ключа этот слой просто пропускается — граф
     строится только словарным слоем (честная деградация, не фантазирование)."""
import json
import re
from typing import Dict, List, Optional

from . import db, synonyms
from .llm import llm

_YEAR_RANGE = re.compile(r"\b(19|20)\d{2}\s*[-–—]\s*(19|20)\d{2}\b")
_YEAR_SINGLE = re.compile(r"\bв?\s*(19|20)\d{2}\s*(году?|г\.?|year|año)?\b", re.IGNORECASE)
_TEAM_HINT = re.compile(
    r"(?:лаборатори[яи]|команда|авторы?|исполнител[ья]|institute|university|"
    r"laboratorio|universidad|team)\s*[:\-]?\s*([A-ZА-ЯЁ][\w \-\.]{2,60})",
    re.UNICODE)

_RU_ALPHA = re.compile(r"[а-яё]")
_ES_HINTS = re.compile(r"\b(el|la|los|las|de|del|para|con|más|más|niquel|níquel|cobre)\b", re.IGNORECASE)
_EN_HINTS = re.compile(r"\b(the|and|for|with|process|material|report|study)\b", re.IGNORECASE)


def detect_language(text: str) -> str:
    """Грубая, но рабочая эвристика по частотным словам/алфавиту — без моделей.
    Возвращает 'ru' | 'en' | 'es' | '?' (не удалось определить)."""
    if not text or not text.strip():
        return "?"
    sample = text[:3000]
    if _RU_ALPHA.search(sample):
        return "ru"
    es_hits = len(_ES_HINTS.findall(sample))
    en_hits = len(_EN_HINTS.findall(sample))
    if es_hits > en_hits and es_hits > 0:
        return "es"
    if en_hits > 0:
        return "en"
    return "?"


def _slug(s: str) -> str:
    return re.sub(r"[^\w]+", "_", s.strip().lower()).strip("_")[:60]


def _extract_time_ranges(text: str) -> List[dict]:
    out = []
    for m in _YEAR_RANGE.finditer(text):
        out.append({"canonical": m.group(0).replace(" ", ""), "kind": "range"})
    covered = {m.span() for m in _YEAR_RANGE.finditer(text)}
    for m in _YEAR_SINGLE.finditer(text):
        if any(a <= m.start() < b for a, b in covered):
            continue
        year = re.search(r"(19|20)\d{2}", m.group(0)).group(0)
        out.append({"canonical": year, "kind": "single"})
    # dedup
    seen, res = set(), []
    for t in out:
        if t["canonical"] not in seen:
            seen.add(t["canonical"]); res.append(t)
    return res[:5]


def _extract_team_hints(text: str) -> List[str]:
    names = []
    for m in _TEAM_HINT.finditer(text):
        name = m.group(1).strip(" .")
        if 2 < len(name) < 60:
            names.append(name)
    # dedup, keep order
    seen, res = set(), []
    for n in names:
        if n.lower() not in seen:
            seen.add(n.lower()); res.append(n)
    return res[:5]


LLM_EXTRACT_SYS = (
    "Ты извлекаешь структурированные данные из технического документа для графа знаний. "
    "Документ может быть на русском, английском или испанском — ВСЕ извлечённые названия "
    "переведи/приведи к русскому каноническому виду (единый граф не делится по языку). "
    "Верни СТРОГО JSON без пояснений:\n"
    '{"entities":[{"type":"material|process|equipment|team","canonical":"..."}],'
    '"relations":[{"subj":"...","predicate":"...","obj":"..."}]}\n'
    "Не более 8 сущностей и 6 связей. Если ничего не найдено — верни пустые списки."
)


def _llm_pass(text: str) -> dict:
    try:
        raw = llm.complete(LLM_EXTRACT_SYS, text[:4000], json_mode=True)
        data = json.loads(raw)
        ents = [e for e in data.get("entities", [])
                if isinstance(e, dict) and e.get("canonical") and e.get("type")]
        rels = [r for r in data.get("relations", [])
                if isinstance(r, dict) and r.get("subj") and r.get("obj")]
        return {"entities": ents[:8], "relations": rels[:6]}
    except Exception as e:
        print(f"[extraction] LLM pass failed ({e}); using dictionary layer only")
        return {"entities": [], "relations": []}


def extract_document(con, doc_id: str, title: str, text: str, use_llm: Optional[bool] = None) -> dict:
    """Строит и сохраняет кусок графа для документа. Возвращает сводку для трассы."""
    from .config import settings
    if use_llm is None:
        use_llm = settings.extraction_llm_enabled

    db.clear_graph_for_doc(con, doc_id)
    full = f"{title}. {text}"
    lang = detect_language(full)

    summary = {"lang": lang, "materials": [], "processes": [], "equipment": [],
               "geography": [], "time": [], "team": [], "constraints": 0,
               "relations": 0, "llm_used": False}

    # 1) словарный слой — материалы/процессы/оборудование/домены
    hits = synonyms.canonicalize(full)
    concept_ids_by_type: Dict[str, List[str]] = {}
    for form, concept in hits:
        db.upsert_entity(con, concept["id"], concept["type"], concept["canonical"], concept["id"])
        mentions = full.lower().count(form)
        db.link_doc_entity(con, doc_id, concept["id"], mentions=max(mentions, 1))
        concept_ids_by_type.setdefault(concept["type"], []).append(concept["id"])
        bucket = {"material": "materials", "process": "processes",
                  "equipment": "equipment", "domain": "processes"}.get(concept["type"])
        if bucket and concept["canonical"] not in summary[bucket]:
            summary[bucket].append(concept["canonical"])

    # 2) география
    geo_hits = synonyms.find_geography(full)
    geo_ids = []
    for g in geo_hits:
        eid = f"geo:{_slug(g['canonical'])}"
        db.upsert_entity(con, eid, "geography", g["canonical"])
        db.link_doc_entity(con, doc_id, eid)
        geo_ids.append(eid)
        summary["geography"].append(g["canonical"])

    # 3) временной диапазон
    time_hits = _extract_time_ranges(full)
    time_ids = []
    for t in time_hits:
        eid = f"time:{_slug(t['canonical'])}"
        db.upsert_entity(con, eid, "time", t["canonical"])
        db.link_doc_entity(con, doc_id, eid)
        time_ids.append(eid)
        summary["time"].append(t["canonical"])

    # 4) команда/авторы (эвристика по ключевым словам-маркерам)
    team_ids = []
    for name in _extract_team_hints(full):
        eid = f"team:{_slug(name)}"
        db.upsert_entity(con, eid, "team", name)
        db.link_doc_entity(con, doc_id, eid)
        team_ids.append(eid)
        summary["team"].append(name)

    # 5) числовые ограничения/условия эксперимента
    constraints = synonyms.extract_constraints(full)
    mats_procs = (concept_ids_by_type.get("material", []) +
                  concept_ids_by_type.get("process", []))
    for c in constraints:
        entity_id = mats_procs[0] if mats_procs else None
        db.add_constraint(con, doc_id, entity_id, c)
    summary["constraints"] = len(constraints)

    # 6) базовые связи-цепочки: материал -> процесс -> оборудование,
    # процесс -> география, процесс -> время (скелет для визуализации цепочек)
    rel_count = 0
    mats = concept_ids_by_type.get("material", [])
    procs = concept_ids_by_type.get("process", [])
    equips = concept_ids_by_type.get("equipment", [])
    for m in mats[:2]:
        for p in procs[:2]:
            db.add_relation(con, doc_id, m, "исследован_в_процессе", p, 0.6)
            rel_count += 1
    for p in procs[:2]:
        for eq in equips[:2]:
            db.add_relation(con, doc_id, p, "выполняется_на", eq, 0.6)
            rel_count += 1
        for g in geo_ids[:2]:
            db.add_relation(con, doc_id, p, "применялся_в", g, 0.6)
            rel_count += 1
        for t in time_ids[:2]:
            db.add_relation(con, doc_id, p, "период", t, 0.6)
            rel_count += 1
    for tm in team_ids[:2]:
        for p in procs[:1]:
            db.add_relation(con, doc_id, tm, "исследовала", p, 0.5)
            rel_count += 1

    # 7) LLM-слой (опционально) — термины и связи вне словаря
    if use_llm:
        llm_res = _llm_pass(full)
        if llm_res["entities"] or llm_res["relations"]:
            summary["llm_used"] = True
        name_to_id = {}
        for e in llm_res["entities"]:
            eid = f"generated:{e['type']}:{_slug(e['canonical'])}"
            db.upsert_entity(con, eid, e["type"], e["canonical"])
            db.link_doc_entity(con, doc_id, eid)
            name_to_id[e["canonical"].lower()] = eid
            bucket = {"material": "materials", "process": "processes",
                      "equipment": "equipment", "team": "team"}.get(e["type"])
            if bucket and e["canonical"] not in summary[bucket]:
                summary[bucket].append(e["canonical"])
        for r in llm_res["relations"]:
            subj_id = name_to_id.get(r["subj"].lower())
            obj_id = name_to_id.get(r["obj"].lower())
            if subj_id and obj_id:
                db.add_relation(con, doc_id, subj_id, r.get("predicate", "связан_с"), obj_id, 0.4)
                rel_count += 1

    summary["relations"] = rel_count
    con.commit()
    return summary
