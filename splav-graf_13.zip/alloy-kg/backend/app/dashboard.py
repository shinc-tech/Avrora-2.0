"""Дашборд руководителя: метрики покрытия знаний по направлениям, активность
команд/источников, зоны риска (мало источников или есть пробел/противоречие).
Пересчитывается НЕ автоматически — только по явному запросу (кнопка
«Обновить» на фронте -> POST /api/dashboard/refresh), т.к. включает
LLM-суммаризацию корпуса. GET /api/dashboard отдаёт последний расчёт и
признак is_stale, если документов с момента расчёта стало больше/меньше."""
import json
import sqlite3
import time
from typing import Optional

from . import db, synonyms
from .graph_store import Graph
from .llm import llm

_TABLE = """
CREATE TABLE IF NOT EXISTS dashboard_cache(
    id INTEGER PRIMARY KEY CHECK(id=1),
    computed_at TEXT, doc_count_at_compute INTEGER, payload TEXT
);
"""

SUMMARY_SYS = (
    "Ты готовишь краткую сводку для руководителя по корпусу технических "
    "документов. На основе присланной статистики (направления, количество "
    "источников, зоны риска) напиши 2-4 предложения по-русски: что покрыто "
    "хорошо, что представляет риск (мало источников/пробелы). Без Markdown."
)


def ensure_table(con: sqlite3.Connection):
    con.executescript(_TABLE)
    con.commit()


def _direction_of_entity(entity_id: str, concept_id: Optional[str]) -> str:
    if concept_id and concept_id in synonyms.DIRECTION_BY_CONCEPT:
        return synonyms.DIRECTION_BY_CONCEPT[concept_id]
    return "прочее"


def compute(con: sqlite3.Connection) -> dict:
    ensure_table(con)
    graph_data = db.load_graph(con)
    g = Graph(graph_data)

    # покрытие по направлениям: сколько уникальных документов затрагивают направление
    # (география/время/команда не являются «технологическим направлением» — не считаем)
    direction_docs = {d: set() for d in synonyms.ALL_DIRECTIONS}
    for de in graph_data["doc_entities"]:
        ent = graph_data["entities"].get(de["entity_id"])
        if not ent or ent["type"] not in ("material", "process", "equipment", "domain"):
            continue
        direction = _direction_of_entity(de["entity_id"], ent.get("concept_id"))
        direction_docs.setdefault(direction, set()).add(de["doc_id"])
    coverage = [{"direction": d, "doc_count": len(docs)} for d, docs in direction_docs.items()]
    coverage.sort(key=lambda x: -x["doc_count"])

    # активность "команд" (упомянутые лаборатории/авторы) — по числу документов
    teams = [{"label": e["canonical"], "doc_count": g.coverage(e["id"])}
             for e in graph_data["entities"].values() if e["type"] == "team"]
    teams = [t for t in teams if t["doc_count"] > 0]
    teams.sort(key=lambda t: -t["doc_count"])

    # зоны риска: направления с < 2 источников, либо явные пробелы, зафиксированные
    # как отсутствие пересечения часто запрашиваемых комбинаций (эвристика на
    # основе текущего состояния графа: сущности с ровно 1 источником — недостаточно
    # подтверждённые данные)
    risk = []
    for d in coverage:
        if d["doc_count"] < 2:
            risk.append({"kind": "низкое покрытие", "label": d["direction"],
                        "note": f"направление «{d['direction']}» подтверждено только "
                                f"{d['doc_count']} источником(ами)"})
    low_conf_entities = [e for e in graph_data["entities"].values()
                         if g.coverage(e["id"]) == 1 and e["type"] in ("material", "process")]
    for e in low_conf_entities[:8]:
        risk.append({"kind": "единственный источник", "label": e["canonical"],
                    "note": f"«{e['canonical']}» упоминается только в одном документе — "
                            "нет перекрёстного подтверждения"})

    stats = {
        "documents": len(graph_data["documents"]),
        "entities": len(graph_data["entities"]),
        "relations": len(graph_data["relations"]),
        "coverage": coverage,
        "teams": teams,
        "risk_zones": risk[:12],
    }

    # LLM-суммаризация (или детерминированный шаблон офлайн)
    if llm.available:
        try:
            prompt = json.dumps({"coverage": coverage, "risk_zones": risk[:8],
                                 "documents": stats["documents"]}, ensure_ascii=False)
            stats["summary"] = llm.complete(SUMMARY_SYS, prompt, json_mode=False)
        except Exception as e:
            stats["summary"] = _offline_summary(stats)
    else:
        stats["summary"] = _offline_summary(stats)

    payload = json.dumps(stats, ensure_ascii=False)
    con.execute("INSERT OR REPLACE INTO dashboard_cache(id,computed_at,doc_count_at_compute,payload) "
                "VALUES(1,?,?,?)", (str(int(time.time())), stats["documents"], payload))
    con.commit()
    return stats


def _offline_summary(stats: dict) -> str:
    top = stats["coverage"][0]["direction"] if stats["coverage"] else None
    risky = len(stats["risk_zones"])
    parts = []
    if top:
        parts.append(f"Лучше всего покрыто направление «{top}».")
    if risky:
        parts.append(f"Обнаружено зон риска: {risky} — темы с малым числом источников, "
                     "требуют дополнительных данных.")
    else:
        parts.append("Явных зон риска по текущему корпусу не выявлено.")
    return " ".join(parts) or "Недостаточно данных для сводки."


def get_cached(con: sqlite3.Connection) -> Optional[dict]:
    ensure_table(con)
    row = con.execute("SELECT * FROM dashboard_cache WHERE id=1").fetchone()
    if not row:
        return None
    payload = json.loads(row["payload"])
    current_docs = db.counts(con)["documents"]
    payload["computed_at"] = row["computed_at"]
    payload["is_stale"] = current_docs != row["doc_count_at_compute"]
    payload["current_documents"] = current_docs
    return payload
