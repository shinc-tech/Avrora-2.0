"""Генерация PDF-отчёта по ответу системы (для скачивания учёным).
Использует reportlab; шрифт DejaVu Sans зарегистрирован из бандла в
app/assets/fonts — работает на любой машине независимо от системных шрифтов."""
import os
import re
import uuid
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, HRFlowable, PageBreak)

from .config import settings

_FONTS_DIR = os.path.join(os.path.dirname(__file__), "assets", "fonts")
_FONT_REGULAR = "DejaVuSans"
_FONT_BOLD = "DejaVuSans-Bold"
_registered = False


def _ensure_fonts():
    global _registered
    if _registered:
        return
    pdfmetrics.registerFont(TTFont(_FONT_REGULAR, os.path.join(_FONTS_DIR, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont(_FONT_BOLD, os.path.join(_FONTS_DIR, "DejaVuSans-Bold.ttf")))
    _registered = True


def _strip_html(s: str) -> str:
    """Убирает ТОЛЬКО наш собственный формат цитатных ссылок
    (<span class="cite" data-ev="ev1">[1]</span> -> [1]), затем правильно и
    однократно экранирует для мини-XML разметки reportlab.

    Намеренно НЕ используется общий regex вида <[^>]+> для "зачистки HTML":
    в сыром тексте документов литеральные конструкции вроде
    "сера < 0.02%, кислород > 0.01%" сами выглядят как открывающий и
    закрывающий тег с содержимым между ними — общий regex стирал бы такой
    текст целиком. Единственная реальная разметка, которую мы когда-либо
    вставляем сами — этот конкретный span цитаты, поэтому вырезаем только его.

    unescape() перед экранированием нужен, т.к. часть входных строк (ответ
    оркестратора) уже была HTML-экранирована выше по стеку через orchestrator's
    _esc(), а часть (сырой текст документов) — никогда; без нормализации первое
    задвоится в "&amp;amp;", а второе сломает Paragraph на литеральных <, >, &."""
    import html as _html
    s = s or ""
    s = re.sub(r'<span class="cite" data-ev="ev\d+">(.*?)</span>', r"\1", s)
    s = _html.unescape(s)
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return s


def build_report(payload: dict) -> str:
    """payload: {query, answer:{segments,why}, evidence, gaps, dedup}. Возвращает
    путь к сохранённому PDF-файлу в settings.reports_dir."""
    _ensure_fonts()
    styles = getSampleStyleSheet()
    for name in list(styles.byName):
        styles[name].fontName = _FONT_REGULAR
    h1 = ParagraphStyle("H1", parent=styles["Heading1"], fontName=_FONT_BOLD,
                         fontSize=16, spaceAfter=10, textColor=colors.HexColor("#1F5C8F"))
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontName=_FONT_BOLD,
                         fontSize=12.5, spaceBefore=14, spaceAfter=6,
                         textColor=colors.HexColor("#1F5C8F"))
    body = ParagraphStyle("Body", parent=styles["Normal"], fontName=_FONT_REGULAR,
                          fontSize=10, leading=14)
    small = ParagraphStyle("Small", parent=styles["Normal"], fontName=_FONT_REGULAR,
                           fontSize=8.5, leading=11, textColor=colors.HexColor("#5A6B7A"))

    fname = f"report-{datetime.now().strftime('%y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}.pdf"
    fpath = os.path.join(settings.reports_dir, fname)
    doc = SimpleDocTemplate(fpath, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                            topMargin=18 * mm, bottomMargin=18 * mm)
    story = []
    story.append(Paragraph("Сплав-Граф — отчёт по запросу", h1))
    story.append(Paragraph(f"Сформирован: {datetime.now().strftime('%d.%m.%Y %H:%M')}", small))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#D8DEE4")))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Вопрос", h2))
    story.append(Paragraph(_strip_html(payload.get("query", "")), body))

    story.append(Paragraph("Ответ", h2))
    for seg in payload.get("answer", {}).get("segments", []):
        story.append(Paragraph(_strip_html(seg.get("html", "")), body))
        story.append(Spacer(1, 3))

    why = payload.get("answer", {}).get("why")
    if why:
        story.append(Paragraph("Почему так", h2))
        story.append(Paragraph(_strip_html(why), body))

    gaps = payload.get("gaps") or []
    story.append(Paragraph("Пробелы в знаниях", h2))
    if gaps:
        for g in gaps:
            story.append(Paragraph(f"• {_strip_html(g.get('note',''))}", body))
    else:
        story.append(Paragraph("По запрошенной комбинации явных пробелов не выявлено.", body))

    dedup = payload.get("dedup") or []
    if dedup:
        story.append(Paragraph("Дублирование по источникам", h2))
        rows = [["Понятие", "Тип", "Источников"]]
        for d in dedup:
            rows.append([d.get("canonical", ""), d.get("type", ""), str(d.get("doc_count", 0))])
        t = Table(rows, colWidths=[70 * mm, 40 * mm, 30 * mm])
        t.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), _FONT_REGULAR),
            ("FONTNAME", (0, 0), (-1, 0), _FONT_BOLD),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EAF1F7")),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#D8DEE4")),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)

    evidence = payload.get("evidence") or []
    if evidence:
        story.append(Paragraph("Ссылки на источники", h2))
        for ev in evidence:
            v = ev.get("verification", {})
            head = f"[{ev['id'].replace('ev','')}] {ev.get('title','')}"
            story.append(Paragraph(head, ParagraphStyle("EvH", parent=body, fontName=_FONT_BOLD)))
            meta = (f"источник: {v.get('source','—')} · достоверность: "
                    f"{round((v.get('confidence') or 0)*100)}% · "
                    f"география: {v.get('geo_scope') or '—'} · язык: {v.get('lang') or '—'}")
            story.append(Paragraph(meta, small))
            snippet = (ev.get("snippet") or "")[:500]
            story.append(Paragraph(_strip_html(snippet), body))
            story.append(Spacer(1, 6))

    # Полные тексты документов-источников — отчёт должен содержать не только
    # цитаты, но и сами документы, на которых основан ответ.
    full_docs = payload.get("full_documents") or []
    if full_docs:
        story.append(PageBreak())
        story.append(Paragraph("Приложение: полные тексты документов-источников", h1))
        for i, fd in enumerate(full_docs):
            if i > 0:
                story.append(PageBreak())
            story.append(Paragraph(fd.get("title", fd.get("id", "")), h2))
            meta_bits = [fd.get("type") or "Документ", fd.get("id", "")]
            if fd.get("source"):
                meta_bits.append(fd["source"])
            story.append(Paragraph(" · ".join(meta_bits), small))
            story.append(Spacer(1, 6))
            text = fd.get("text") or "(текст не извлечён)"
            # разбиваем на абзацы — reportlab плохо переносит очень длинные Paragraph
            for para in text.split("\n"):
                if para.strip():
                    story.append(Paragraph(_strip_html(para), body))
                    story.append(Spacer(1, 3))

    doc.build(story)
    return fpath
