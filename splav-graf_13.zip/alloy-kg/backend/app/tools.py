"""Инструменты оркестратора: поиск по фрагментам ВСЕХ документов, агрегация
покрытия по сущностям (для подсветки дублирования между источниками) и
обнаружение пробелов знаний (запрошенная комбинация сущностей без источников)."""
import json
import re
from typing import Dict, List, Optional

from .embeddings import embedder, cosine
from . import synonyms

_WORD = re.compile(r"[\wёЁа-яА-Я0-9\-]+", re.UNICODE)

_STOP = {"и", "в", "во", "по", "на", "о", "об", "про", "что", "как", "какие",
         "какой", "какая", "какое", "есть", "для", "ли", "это", "из", "при",
         "с", "со", "у", "к", "до", "от", "же", "или", "а", "но", "не", "был",
         "была", "было", "были", "его", "их", "там", "так", "тех", "над",
         "данные", "данных", "информация", "информацию", "расскажи", "покажи",
         "найди", "известно", "сделали", "делали"}


def _terms(q: str) -> List[str]:
    return [w.lower() for w in _WORD.findall(q) if len(w) > 2 and w.lower() not in _STOP]


def _word_hits(terms: List[str], text_low: str) -> List[str]:
    matched = []
    for t in terms:
        if len(t) >= 4:
            stem = re.escape(t[:max(4, len(t) - 2)])
            if re.search(rf"\b{stem}", text_low):
                matched.append(t)
        else:
            if re.search(rf"\b{re.escape(t)}\b", text_low):
                matched.append(t)
    return matched


def chunk_search(q: str, con, top_k: int = 8, doc_ids: Optional[List[str]] = None) -> List[dict]:
    """Гибридный поиск по фрагментам ВСЕХ (или ограниченного набора doc_ids)
    загруженных документов: семантика + лексика по корню слова."""
    qv = embedder.embed([q])[0]
    terms = _terms(q)
    sql = ("SELECT c.*, d.title AS doc_title, d.type AS doc_type, d.source AS doc_source, "
           "d.confidence AS doc_confidence, d.geo_scope AS doc_geo, d.added_at AS doc_added_at, "
           "d.lang AS doc_lang FROM chunks c JOIN documents d ON d.id=c.doc_id")
    params = []
    if doc_ids:
        sql += f" WHERE c.doc_id IN ({','.join('?' * len(doc_ids))})"
        params = list(doc_ids)
    rows = list(con.execute(sql, params))
    if not rows:
        return []
    scored = []
    for r in rows:
        v = json.loads(r["vec"])
        sem = cosine(qv, v)
        low = (r["text"] or "").lower()
        matched = _word_hits(terms, low)
        hits = len(matched)
        lex = hits / len(terms) if terms else 0.0
        score = 0.6 * sem + 0.4 * lex
        scored.append((score, sem, hits, matched, r))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for i, (score, sem, hits, matched, r) in enumerate(scored[:top_k]):
        out.append({
            "n": i + 1, "doc_id": r["doc_id"], "chunk_id": r["id"],
            "title": r["doc_title"] or r["doc_id"], "doc_type": r["doc_type"] or "Документ",
            "source": r["doc_source"], "confidence": r["doc_confidence"],
            "geo_scope": r["doc_geo"], "added_at": r["doc_added_at"], "lang": r["doc_lang"],
            "text": r["text"], "start": r["start"], "end": r["end"],
            "score": round(score, 3), "sem": round(sem, 3),
            "term_hits": hits, "matched_terms": matched,
        })
    return out


def query_entities(query: str) -> dict:
    """Сущности/география/числовые ограничения, распознанные прямо в запросе
    пользователя (тот же словарь, что и при загрузке документов -> единый
    граф, независимый от языка формулировки вопроса)."""
    hits = synonyms.canonicalize(query)
    geo = synonyms.find_geography(query)
    constraints = synonyms.extract_constraints(query)
    return {
        "concepts": [{"id": c["id"], "type": c["type"], "canonical": c["canonical"]}
                     for _, c in hits],
        "geography": geo,
        "constraints": constraints,
    }


def entity_coverage(con, entity_ids: List[str]) -> Dict[str, dict]:
    """Для каждой сущности — в скольких РАЗНЫХ документах она встречается
    (частота/дублирование источников) + список этих документов."""
    if not entity_ids:
        return {}
    q = ("SELECT de.entity_id, de.doc_id, d.title, de.mentions "
         f"FROM doc_entities de JOIN documents d ON d.id=de.doc_id "
         f"WHERE de.entity_id IN ({','.join('?' * len(entity_ids))})")
    out = {eid: {"doc_count": 0, "docs": []} for eid in entity_ids}
    for r in con.execute(q, entity_ids):
        out[r["entity_id"]]["doc_count"] += 1
        out[r["entity_id"]]["docs"].append({"doc_id": r["doc_id"], "title": r["title"],
                                            "mentions": r["mentions"]})
    return out


def combo_coverage(con, entity_ids: List[str]) -> dict:
    """Сколько документов содержат ВСЕ перечисленные сущности одновременно
    (комбинация материал+процесс+география и т.п.) — это и есть проверка
    «дублирования метода в этой географии» / основа для поиска пробелов."""
    if not entity_ids:
        return {"doc_count": 0, "docs": []}
    q = (f"SELECT doc_id, COUNT(DISTINCT entity_id) AS n FROM doc_entities "
         f"WHERE entity_id IN ({','.join('?' * len(entity_ids))}) "
         f"GROUP BY doc_id HAVING n = ?")
    rows = con.execute(q, entity_ids + [len(entity_ids)]).fetchall()
    doc_ids = [r["doc_id"] for r in rows]
    if not doc_ids:
        return {"doc_count": 0, "docs": []}
    titles = con.execute(
        f"SELECT id, title FROM documents WHERE id IN ({','.join('?' * len(doc_ids))})",
        doc_ids).fetchall()
    return {"doc_count": len(doc_ids),
            "docs": [{"doc_id": t["id"], "title": t["title"]} for t in titles]}


def detect_gaps(con, concepts: List[dict], geo: List[dict]) -> List[dict]:
    """Пробелы знаний: запрошенная комбинация сущностей (материал/процесс +
    география/климат), для которой нет ни одного источника, при том что
    каждая сущность по отдельности в базе встречается (иначе это не пробел,
    а просто отсутствие данных вообще)."""
    def _slug(s):
        return re.sub(r"[^\w]+", "_", s.strip().lower()).strip("_")[:60]
    ids = [c["id"] for c in concepts] + ["geo:" + _slug(g["canonical"]) for g in geo]
    if len(ids) < 2:
        return []
    individual = entity_coverage(con, ids)
    combo = combo_coverage(con, ids)
    if combo["doc_count"] > 0:
        return []  # комбинация покрыта — не пробел
    if all(individual.get(i, {}).get("doc_count", 0) == 0 for i in ids):
        return []  # ничего из этого вообще нет в базе — не «пробел в комбинации», а просто нет данных
    names = [c["canonical"] for c in concepts] + [g["canonical"] for g in geo]
    return [{
        "combo": " + ".join(names),
        "note": f"нет источников, где одновременно упоминаются: {', '.join(names)}",
        "have_individually": {n: individual.get(i, {}).get("doc_count", 0)
                              for n, i in zip(names, ids)},
    }]
