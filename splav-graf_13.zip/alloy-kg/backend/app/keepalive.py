"""Self-ping: не даёт бесплатному Replit "усыпить" приложение от простоя.

Работает ТОЛЬКО для обычного запуска Repl (кнопка Run, режим разработки) —
именно там процесс один и диск персистентный, поэтому имеет смысл держать
его "разбуженным". Формальный Deploy (Autoscale) диск не сохраняет в любом
случае — self-ping там не спасёт данные, только тратит впустую квоту.

Приоритет определения адреса для пинга:
  1. SELF_PING_URL (явно задан) — самый надёжный вариант;
  2. REPLIT_DOMAINS (текущая переменная окружения Replit с публичным доменом);
  3. ничего не найдено -> self-ping тихо отключается (лог одной строкой),
     приложение продолжает работать как обычно."""
import threading
import time

import requests

from .config import settings


def _resolve_ping_url() -> str:
    if settings.self_ping_url:
        return settings.self_ping_url.rstrip("/")
    import os
    domains = os.getenv("REPLIT_DOMAINS", "")
    if domains:
        first = domains.split(",")[0].strip()
        if first:
            return f"https://{first}"
    return ""


def _loop(url: str, interval_sec: int):
    while True:
        time.sleep(interval_sec)
        try:
            requests.get(url + "/api/health", timeout=15)
        except Exception as e:
            print(f"[keepalive] self-ping не удался (не критично): {e}")


def start():
    if settings.self_ping_minutes <= 0:
        return
    url = _resolve_ping_url()
    if not url:
        print("[keepalive] SELF_PING_URL не задан и REPLIT_DOMAINS не найден — "
              "self-ping отключён (это нормально вне Replit)")
        return
    interval = settings.self_ping_minutes * 60
    print(f"[keepalive] self-ping включён: {url}/api/health каждые "
          f"{settings.self_ping_minutes} мин.")
    t = threading.Thread(target=_loop, args=(url, interval), daemon=True)
    t.start()
