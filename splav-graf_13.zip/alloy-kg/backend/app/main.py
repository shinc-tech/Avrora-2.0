"""FastAPI-приложение: API + отдача собранного фронтенда."""
import os
import re
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db, orchestrator, ingest_content, extraction, dashboard, tools, synonyms, keepalive
from .graph_store import Graph
from .config import settings
from .llm import llm
from .pdf_report import build_report

app = FastAPI(title="Сплав-Граф API", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.exception_handler(Exception)
async def _unhandled_exception_handler(request, exc):
    # Последняя линия обороны для ВСЕХ эндпоинтов: без этого необработанное
    # исключение может оборвать соединение так, что fetch() на фронте увидит
    # это как «сетевую ошибку» вместо понятного сообщения.
    print(f"[unhandled] {request.method} {request.url.path}: {exc}")
    return JSONResponse(status_code=500, content={
        "status": "error",
        "message": f"внутренняя ошибка сервера: {exc}",
        "path": str(request.url.path),
    })


@app.on_event("startup")
def _startup():
    db.init_db()
    con = db.connect()
    dashboard.ensure_table(con)
    con.close()
    keepalive.start()


class ChatIn(BaseModel):
    query: str
    geo_filter: Optional[str] = None   # domestic | foreign | None
    chat_id: Optional[str] = None      # если задан, сообщение сохраняется в историю вкладки


class ChatCreateIn(BaseModel):
    title: Optional[str] = None


class UrlIn(BaseModel):
    url: str


class ReportIn(BaseModel):
    query: str
    answer: dict
    evidence: List[dict] = []
    gaps: List[dict] = []
    dedup: List[dict] = []


# --------------------------------------------------------------------------- #
#  Health
# --------------------------------------------------------------------------- #
@app.get("/api/health")
def health():
    con = db.connect()
    try:
        c = db.counts(con)
        return {
            "ok": True, "llm": llm.label, "llm_mock": not llm.available,
            "embedding": settings.embedding_backend,
            "ingest": {"supported_ext": sorted(ingest_content.SUPPORTED_EXT)},
            "directions": synonyms.ALL_DIRECTIONS,
            "self_ping": {"enabled": settings.self_ping_minutes > 0,
                         "interval_minutes": settings.self_ping_minutes,
                         "url": keepalive._resolve_ping_url() or None},
            "storages": [{"id": "local", "name": "Локальное хранилище",
                         "detail": "SQLite + граф + вектор", "active": True},
                        {"id": "external", "name": "LIMS-каталог (внешний)",
                         "detail": "REST · не подключён", "active": False}],
            "corpus": c,
        }
    finally:
        con.close()


# --------------------------------------------------------------------------- #
#  Документы
# --------------------------------------------------------------------------- #
def _confidence_and_geo(origin: str, source: Optional[str], has_text_layer: bool, text: str):
    conf = 0.5
    if has_text_layer:
        conf += 0.15
    if len(text) > 800:
        conf += 0.1
    if origin == "url" and source:
        low = source.lower()
        if any(d in low for d in [".gov", ".edu", "scholar.", "elsevier", "sciencedirect",
                                   "researchgate", "springer", "ieee", "doi.org", ".ac."]):
            conf += 0.2
    conf = round(min(conf, 0.95), 2)
    lang = extraction.detect_language(text)
    geo = synonyms.geo_for_document(text, lang)
    scope = geo["scope"] if geo else None
    label = geo["canonical"] if geo else None
    return conf, scope, label, lang


def _ingest_and_extract(con, doc_id: str, title: str, dtype: str, text: str,
                        origin: str, source: Optional[str], has_text_layer: bool,
                        images_count: int) -> dict:
    conf, geo_scope, geo_label, lang = _confidence_and_geo(origin, source, has_text_layer, text)
    db.add_document(con, {"id": doc_id, "title": title, "type": dtype, "text": text,
                          "origin": origin, "source": source,
                          "has_text_layer": has_text_layer, "images_count": images_count,
                          "confidence": conf, "geo_scope": geo_scope, "geo_label": geo_label,
                          "lang": lang})
    empty_graph = {"lang": lang, "materials": [], "processes": [], "equipment": [], "geography": [],
                   "time": [], "team": [], "constraints": 0, "relations": 0, "llm_used": False,
                   "error": None}
    graph_summary = empty_graph
    if text.strip():
        try:
            graph_summary = extraction.extract_document(con, doc_id, title, text)
            graph_summary["error"] = None
        except Exception as e:
            # документ уже сохранён (см. выше) — сбой построения графа не должен
            # ронять всю загрузку, просто честно сообщаем об этом
            print(f"[upload] extraction.extract_document failed for {doc_id}: {e}")
            graph_summary = dict(empty_graph, error=str(e))
    return {"confidence": conf, "geo_scope": geo_scope, "geo_label": geo_label, "graph": graph_summary}


@app.get("/api/documents")
def documents():
    con = db.connect()
    try:
        return {"documents": db.list_documents(con),
                "supported_ext": sorted(ingest_content.SUPPORTED_EXT)}
    finally:
        con.close()


@app.get("/api/documents/{doc_id}")
def get_document(doc_id: str):
    con = db.connect()
    try:
        doc = db.get_document(con, doc_id)
        if not doc:
            return JSONResponse(status_code=404, content={"error": "документ не найден"})
        graph = db.load_graph(con)
        ents = [e for e in graph["entities"].values()
                if any(de["doc_id"] == doc_id and de["entity_id"] == e["id"]
                      for de in graph["doc_entities"])]
        cons = [c for c in graph["constraints"] if c["doc_id"] == doc_id]
        doc["graph_entities"] = ents
        doc["graph_constraints"] = cons
        return doc
    finally:
        con.close()


@app.get("/api/documents/{doc_id}/download")
def download_document(doc_id: str):
    con = db.connect()
    try:
        doc = db.get_document(con, doc_id)
        if not doc:
            return JSONResponse(status_code=404, content={"error": "документ не найден"})
    finally:
        con.close()
    safe_name = re.sub(r"[^\w.\-]+", "_", doc["title"] or doc_id) + ".txt"
    return PlainTextResponse(doc["text"] or "", headers={
        "Content-Disposition": f'attachment; filename="{safe_name}"'})


@app.delete("/api/documents/{doc_id}")
def delete_document(doc_id: str):
    con = db.connect()
    try:
        ok = db.delete_document(con, doc_id)
        if not ok:
            return JSONResponse(status_code=404, content={"error": "документ не найден"})
        return {"ok": True, "deleted": doc_id}
    finally:
        con.close()


_MAX_UPLOAD_MB = 60


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    fname = file.filename or "upload.bin"
    base = os.path.splitext(fname)[0]
    ext = os.path.splitext(fname)[1].lower()
    try:
        data = await file.read()
    except Exception as e:
        return JSONResponse(status_code=400, content={"filename": fname, "status": "error",
                            "message": f"не удалось прочитать загруженный файл: {e}"})

    if len(data) > _MAX_UPLOAD_MB * 1024 * 1024:
        return {"filename": fname, "status": "error",
               "message": f"файл больше {_MAX_UPLOAD_MB} МБ — загрузка отклонена"}

    safe = re.sub(r"[^\w.\-]+", "_", fname)
    stamp = datetime.now().strftime("%y%m%d-%H%M%S"); uid = uuid.uuid4().hex[:4]
    dest = os.path.join(settings.uploads_dir, f"{stamp}-{uid}-{safe}")
    try:
        with open(dest, "wb") as out:
            out.write(data)
    except Exception as e:
        return JSONResponse(status_code=500, content={"filename": fname, "status": "error",
                            "message": f"не удалось сохранить файл на сервере: {e}"})

    con = db.connect()
    try:
        # --- ZIP-архив: пакетная обработка, каждый поддерживаемый файл -> отдельный документ
        if ext in ingest_content.ZIP_EXT:
            try:
                members = ingest_content.extract_zip(dest)
            except ingest_content.ExtractError as e:
                return {"filename": fname, "status": "unsupported", "message": str(e)}
            except Exception as e:
                return JSONResponse(status_code=500, content={"filename": fname, "status": "error",
                                    "message": f"не удалось распаковать архив: {e}"})
            results = []
            for member_name, extd, err in members:
                if err is not None or extd is None:
                    results.append({"filename": member_name, "status": "unsupported", "message": err})
                    continue
                try:
                    m_stamp = datetime.now().strftime("%y%m%d-%H%M%S"); m_uid = uuid.uuid4().hex[:4]
                    doc_id = f"DOC-U-{m_stamp}-{m_uid}"
                    m_base = os.path.splitext(os.path.basename(member_name))[0]
                    info = _ingest_and_extract(con, doc_id, f"{base}/{m_base}", "Загружен (из архива)",
                                               extd.text, "upload", f"{fname}:{member_name}",
                                               extd.has_text_layer, extd.images_count)
                    results.append({
                        "filename": member_name,
                        "status": "stored" if extd.has_text_layer else "stored_no_text",
                        "detect": {"kind": extd.kind, "has_text_layer": extd.has_text_layer,
                                  "pages": extd.pages, "images_count": extd.images_count,
                                  "reason": extd.reason},
                        "document": {"id": doc_id, "title": f"{base}/{m_base}", "chars": len(extd.text)},
                        "graph": info["graph"], "confidence": info["confidence"],
                        "geo_scope": info["geo_scope"], "geo_label": info["geo_label"],
                    })
                except Exception as e:
                    print(f"[upload] archive member {member_name} failed: {e}")
                    results.append({"filename": member_name, "status": "error", "message": str(e)})
            stored = sum(1 for r in results if r["status"] in ("stored", "stored_no_text"))
            return {"filename": fname, "status": "archive", "results": results,
                   "total": len(results), "stored": stored}

        # --- обычный файл
        try:
            ext_res = ingest_content.extract_local_file(dest, fname)
        except ingest_content.ExtractError as e:
            return {"filename": fname, "status": "unsupported", "message": str(e)}
        doc_id = f"DOC-U-{stamp}-{uid}"
        info = _ingest_and_extract(con, doc_id, base, "Загружен", ext_res.text, "upload", fname,
                                   ext_res.has_text_layer, ext_res.images_count)
        return {
            "filename": fname,
            "status": "stored" if ext_res.has_text_layer else "stored_no_text",
            "detect": {"kind": ext_res.kind, "has_text_layer": ext_res.has_text_layer,
                      "pages": ext_res.pages, "images_count": ext_res.images_count,
                      "reason": ext_res.reason},
            "document": {"id": doc_id, "title": base, "chars": len(ext_res.text)},
            "graph": info["graph"], "confidence": info["confidence"], "geo_scope": info["geo_scope"], "geo_label": info["geo_label"],
        }
    except Exception as e:
        # последняя линия обороны: НИКОГДА не даём соединению оборваться необработанным
        # исключением — фронт получит понятное сообщение вместо «сетевой ошибки»
        print(f"[upload] unexpected error for {fname}: {e}")
        return JSONResponse(status_code=500, content={"filename": fname, "status": "error",
                            "message": f"внутренняя ошибка сервера при обработке файла: {e}"})
    finally:
        con.close()


@app.post("/api/upload_url")
def upload_url(body: UrlIn):
    con = db.connect()
    try:
        try:
            ext = ingest_content.extract_url(body.url)
        except ingest_content.ExtractError as e:
            return {"url": body.url, "status": "error", "message": str(e)}
        stamp = datetime.now().strftime("%y%m%d-%H%M%S"); uid = uuid.uuid4().hex[:4]
        doc_id = f"DOC-WEB-{stamp}-{uid}"
        title = ext.title or body.url
        info = _ingest_and_extract(con, doc_id, title, "Веб-ресурс", ext.text, "url", body.url,
                                   ext.has_text_layer, ext.images_count)
        return {
            "url": body.url,
            "status": "stored" if ext.has_text_layer else "stored_no_text",
            "detect": {"kind": ext.kind, "has_text_layer": ext.has_text_layer,
                      "pages": ext.pages, "images_count": ext.images_count, "reason": ext.reason},
            "document": {"id": doc_id, "title": title, "chars": len(ext.text)},
            "graph": info["graph"], "confidence": info["confidence"], "geo_scope": info["geo_scope"], "geo_label": info["geo_label"],
        }
    except Exception as e:
        print(f"[upload_url] unexpected error for {body.url}: {e}")
        return JSONResponse(status_code=500, content={"url": body.url, "status": "error",
                            "message": f"внутренняя ошибка сервера: {e}"})
    finally:
        con.close()


# --------------------------------------------------------------------------- #
#  Чаты: вкладки и история (общие для всех, переживают обновление страницы)
# --------------------------------------------------------------------------- #
@app.get("/api/chats")
def get_chats():
    con = db.connect()
    try:
        return {"chats": db.list_chats(con)}
    finally:
        con.close()


@app.post("/api/chats")
def create_chat(body: ChatCreateIn):
    con = db.connect()
    try:
        chat_id = f"chat-{uuid.uuid4().hex[:10]}"
        title = (body.title or "Новый чат").strip() or "Новый чат"
        db.create_chat(con, chat_id, title)
        return db.get_chat(con, chat_id)
    finally:
        con.close()


@app.get("/api/chats/{chat_id}/messages")
def get_chat_messages(chat_id: str):
    con = db.connect()
    try:
        if not db.get_chat(con, chat_id):
            return JSONResponse(status_code=404, content={"error": "чат не найден"})
        return {"messages": db.list_chat_messages(con, chat_id)}
    finally:
        con.close()


@app.delete("/api/chats/{chat_id}")
def remove_chat(chat_id: str):
    con = db.connect()
    try:
        ok = db.delete_chat(con, chat_id)
        if not ok:
            return JSONResponse(status_code=404, content={"error": "чат не найден"})
        return {"ok": True, "deleted": chat_id}
    finally:
        con.close()


# --------------------------------------------------------------------------- #
#  Чат / оркестратор
# --------------------------------------------------------------------------- #
@app.post("/api/chat")
def chat(body: ChatIn):
    con = db.connect()
    try:
        result = orchestrator.run(body.query, con, geo_filter=body.geo_filter)
        if body.chat_id and db.get_chat(con, body.chat_id):
            msg_id = f"msg-{uuid.uuid4().hex[:10]}"
            db.add_chat_message(con, body.chat_id, msg_id, body.query, result)
            # первое сообщение — переименовываем вкладку по тексту вопроса,
            # чтобы у всех, кто откроет приложение, она называлась осмысленно
            existing = db.list_chat_messages(con, body.chat_id)
            if len(existing) == 1:
                title = body.query.strip()
                title = (title[:28] + "…") if len(title) > 28 else title
                db.rename_chat(con, body.chat_id, title or "Новый чат")
        return result
    finally:
        con.close()


@app.post("/api/report/pdf")
def report_pdf(body: ReportIn):
    payload = body.dict()
    # Отчёт должен содержать не только короткие цитаты, но и сами документы
    # целиком — подгружаем полный текст каждого уникального источника из БД.
    con = db.connect()
    try:
        seen, full_docs = set(), []
        for ev in payload.get("evidence", []):
            doc_id = ev.get("source_id")
            if not doc_id or doc_id in seen:
                continue
            seen.add(doc_id)
            doc = db.get_document(con, doc_id)
            if doc:
                full_docs.append({"id": doc_id, "title": doc.get("title") or doc_id,
                                  "type": doc.get("type"), "source": doc.get("source"),
                                  "text": doc.get("text") or ""})
        payload["full_documents"] = full_docs
    finally:
        con.close()
    path = build_report(payload)
    fname = os.path.basename(path)
    return {"ok": True, "file": fname, "url": f"/api/report/pdf/{fname}"}


@app.get("/api/report/pdf/{fname}")
def get_report_pdf(fname: str):
    safe = re.sub(r"[^\w.\-]+", "_", fname)
    path = os.path.join(settings.reports_dir, safe)
    if not os.path.exists(path):
        return JSONResponse(status_code=404, content={"error": "отчёт не найден"})
    return FileResponse(path, media_type="application/pdf", filename="splav-graf-report.pdf")


# --------------------------------------------------------------------------- #
#  Граф (визуализация)
# --------------------------------------------------------------------------- #
@app.get("/api/graph")
def graph_viz(entities: str = ""):
    con = db.connect()
    try:
        ids = [e for e in entities.split(",") if e]
        if not ids:
            gd = db.load_graph(con)
            g = Graph(gd)
            top = g.summary()["top_entities"][:8]
            ids = [t["id"] for t in top]
        g = Graph(db.load_graph(con))
        return g.to_viz(ids)
    finally:
        con.close()


# --------------------------------------------------------------------------- #
#  Дашборд
# --------------------------------------------------------------------------- #
@app.get("/api/dashboard")
def get_dashboard():
    con = db.connect()
    try:
        cached = dashboard.get_cached(con)
        if not cached:
            return {"computed_at": None, "is_stale": True, "current_documents": db.counts(con)["documents"]}
        return cached
    finally:
        con.close()


@app.post("/api/dashboard/refresh")
def refresh_dashboard():
    con = db.connect()
    try:
        dashboard.compute(con)
        # get_cached() — единственное место, где собирается финальная форма ответа
        # (computed_at/is_stale/current_documents); переиспользуем её и здесь,
        # чтобы ответ POST /refresh был идентичен по форме ответу GET /dashboard.
        return dashboard.get_cached(con)
    finally:
        con.close()


# --------------------------------------------------------------------------- #
#  Статика (собранный фронтенд)
# --------------------------------------------------------------------------- #
@app.middleware("http")
async def _no_cache_frontend(request, call_next):
    # Без явного заголовка браузеры могут годами отдавать app.js/index.html из
    # кэша, даже когда файлы на сервере обновились — из-за этого пользователь
    # может тестировать старую версию и не видеть уже исправленных багов.
    # API-ответы (JSON) это не затрагивает — только сама разметка/скрипты/стили.
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.endswith((".html", ".js", ".css")):
        response.headers["Cache-Control"] = "no-cache, must-revalidate"
    return response


_frontend_dir = os.path.join(os.path.dirname(__file__), "..", "..", "frontend")
if os.path.isdir(_frontend_dir):
    app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")
