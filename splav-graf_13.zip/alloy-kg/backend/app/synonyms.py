"""Мультиязычный словарь понятий домена (материалы/процессы/оборудование) и
географии. Единый граф не делится по языку: любая форма слова (RU/EN/ES,
аббревиатура) сворачивается в один canonical-узел через этот словарь.

Структурировано как список записей -> легко расширять новыми доменами
(гидрометаллургия, пирометаллургия, экология, переработка отходов и т.д.),
не трогая код извлечения — только добавляя записи сюда."""
import re
from typing import Dict, List, Optional, Tuple

# --- домен: материалы, процессы, оборудование ------------------------------
# id уникален и стабилен (используется как canonical-ключ узла графа).
CONCEPTS: List[dict] = [
    # металлургия сплавов (существующий демо-домен) -> направление "материаловедение"
    {"id": "material:30hgsa", "type": "material", "canonical": "30ХГСА", "direction": "материаловедение",
     "forms": ["30хгса", "30hgsa", "сталь 30хгса"]},
    {"id": "material:vt6", "type": "material", "canonical": "ВТ6", "direction": "материаловедение",
     "forms": ["вт6", "vt6", "ti-6al-4v", "титан вт6"]},
    {"id": "material:12h18n10t", "type": "material", "canonical": "12Х18Н10Т", "direction": "материаловедение",
     "forms": ["12х18н10т", "нержавейка 12х18н10т", "stainless 12h18n10t"]},
    {"id": "process:additive_manufacturing", "type": "process", "direction": "материаловедение",
     "canonical": "аддитивное производство (3D-печать)",
     "forms": ["3d печать", "3д печать", "3d-печать", "аддитивное производство",
               "3d printing", "additive manufacturing", "slm",
               "selective laser melting", "селективное лазерное плавление",
               "impresión 3d", "impresion 3d", "fabricación aditiva", "fabricacion aditiva"]},
    {"id": "process:heat_treatment", "type": "process", "direction": "материаловедение",
     "canonical": "термообработка",
     "forms": ["термообработка", "heat treatment", "tratamiento térmico", "tratamiento termico"]},
    {"id": "process:quenching", "type": "process", "direction": "материаловедение", "canonical": "закалка",
     "forms": ["закалка", "quenching", "temple"]},
    {"id": "process:tempering", "type": "process", "direction": "материаловедение", "canonical": "отпуск",
     "forms": ["отпуск", "tempering", "revenido"]},
    {"id": "process:annealing", "type": "process", "direction": "материаловедение", "canonical": "отжиг",
     "forms": ["отжиг", "annealing", "recocido"]},
    # гидрометаллургия
    {"id": "material:nickel", "type": "material", "direction": "гидрометаллургия", "canonical": "никель",
     "forms": ["никель", "nickel", "níquel", "niquel", "ni-руда", "никелевая руда"]},
    {"id": "material:copper", "type": "material", "direction": "гидрометаллургия", "canonical": "медь",
     "forms": ["медь", "copper", "cobre"]},
    {"id": "material:gypsum", "type": "material", "direction": "переработка отходов", "canonical": "гипс",
     "forms": ["гипс", "gypsum", "yeso"]},
    {"id": "process:leaching", "type": "process", "direction": "гидрометаллургия", "canonical": "выщелачивание",
     "forms": ["выщелачивание", "leaching", "lixiviación", "lixiviacion"]},
    {"id": "process:heap_leaching", "type": "process", "direction": "гидрометаллургия",
     "canonical": "кучное выщелачивание",
     "forms": ["кучное выщелачивание", "heap leaching",
               "lixiviación en pilas", "lixiviacion en pilas"]},
    {"id": "process:electrowinning", "type": "process", "direction": "гидрометаллургия",
     "canonical": "электроэкстракция",
     "forms": ["электроэкстракция", "electrowinning", "electroextracción",
               "electroextraccion", "эв", "ew"]},
    # пирометаллургия
    {"id": "process:smelting", "type": "process", "direction": "пирометаллургия", "canonical": "плавка",
     "forms": ["плавка", "smelting", "fundición", "fundicion", "пирометаллургия",
               "pyrometallurgy", "pirometalurgia"]},
    {"id": "equipment:fsf", "type": "equipment", "direction": "пирометаллургия",
     "canonical": "печь взвешенной плавки",
     "forms": ["пвп", "печь взвешенной плавки", "fluidized bed furnace", "fsf",
               "horno de lecho fluidizado"]},
    # переработка отходов / экология
    {"id": "process:waste_processing", "type": "process", "direction": "переработка отходов",
     "canonical": "переработка отходов",
     "forms": ["переработка отходов", "waste processing", "waste recycling",
               "reciclaje de residuos", "procesamiento de residuos"]},
    {"id": "process:ecology", "type": "domain", "direction": "экология", "canonical": "экология",
     "forms": ["экология", "ecology", "environmental impact", "impacto ambiental",
               "экологический"]},
]

# --- география: canonical-название + признак "отечественная/зарубежная"
# практика (относительно русскоязычной аудитории системы) ------------------
GEOGRAPHY: Dict[str, dict] = {
    "россия": {"canonical": "Россия", "scope": "domestic"},
    "russia": {"canonical": "Россия", "scope": "domestic"},
    "рф": {"canonical": "Россия", "scope": "domestic"},
    "снг": {"canonical": "СНГ", "scope": "domestic"},
    "казахстан": {"canonical": "Казахстан", "scope": "domestic"},
    "kazakhstan": {"canonical": "Казахстан", "scope": "domestic"},
    "узбекистан": {"canonical": "Узбекистан", "scope": "domestic"},
    "сша": {"canonical": "США", "scope": "foreign"},
    "usa": {"canonical": "США", "scope": "foreign"},
    "united states": {"canonical": "США", "scope": "foreign"},
    "китай": {"canonical": "Китай", "scope": "foreign"},
    "china": {"canonical": "Китай", "scope": "foreign"},
    "чили": {"canonical": "Чили", "scope": "foreign"},
    "chile": {"canonical": "Чили", "scope": "foreign"},
    "перу": {"canonical": "Перу", "scope": "foreign"},
    "peru": {"canonical": "Перу", "scope": "foreign"},
    "perú": {"canonical": "Перу", "scope": "foreign"},
    "германия": {"canonical": "Германия", "scope": "foreign"},
    "germany": {"canonical": "Германия", "scope": "foreign"},
    "канада": {"canonical": "Канада", "scope": "foreign"},
    "canada": {"canonical": "Канада", "scope": "foreign"},
}

# Города (уровень детализации выше страны). Каждый матчится раньше страны —
# «Норильск» даёт более точную географию, чем просто «Россия». country должен
# быть каноническим именем из GEOGRAPHY (или новым — тогда scope берётся отсюда).
CITIES: Dict[str, dict] = {
    "норильск": {"canonical": "Норильск", "country": "Россия", "scope": "domestic"},
    "norilsk": {"canonical": "Норильск", "country": "Россия", "scope": "domestic"},
    "москва": {"canonical": "Москва", "country": "Россия", "scope": "domestic"},
    "moscow": {"canonical": "Москва", "country": "Россия", "scope": "domestic"},
    "екатеринбург": {"canonical": "Екатеринбург", "country": "Россия", "scope": "domestic"},
    "челябинск": {"canonical": "Челябинск", "country": "Россия", "scope": "domestic"},
    "норильлаг": {"canonical": "Норильск", "country": "Россия", "scope": "domestic"},
    "магнитогорск": {"canonical": "Магнитогорск", "country": "Россия", "scope": "domestic"},
    "мончегорск": {"canonical": "Мончегорск", "country": "Россия", "scope": "domestic"},
    "алматы": {"canonical": "Алматы", "country": "Казахстан", "scope": "domestic"},
    "almaty": {"canonical": "Алматы", "country": "Казахстан", "scope": "domestic"},
    "астана": {"canonical": "Астана", "country": "Казахстан", "scope": "domestic"},
    "сантьяго": {"canonical": "Сантьяго", "country": "Чили", "scope": "foreign"},
    "santiago": {"canonical": "Сантьяго", "country": "Чили", "scope": "foreign"},
    "антофагаста": {"canonical": "Антофагаста", "country": "Чили", "scope": "foreign"},
    "antofagasta": {"canonical": "Антофагаста", "country": "Чили", "scope": "foreign"},
    "калама": {"canonical": "Калама", "country": "Чили", "scope": "foreign"},
    "calama": {"canonical": "Калама", "country": "Чили", "scope": "foreign"},
    "лима": {"canonical": "Лима", "country": "Перу", "scope": "foreign"},
    "lima": {"canonical": "Лима", "country": "Перу", "scope": "foreign"},
    "арекипа": {"canonical": "Арекипа", "country": "Перу", "scope": "foreign"},
    "arequipa": {"canonical": "Арекипа", "country": "Перу", "scope": "foreign"},
    "пекин": {"canonical": "Пекин", "country": "Китай", "scope": "foreign"},
    "beijing": {"canonical": "Пекин", "country": "Китай", "scope": "foreign"},
    "шанхай": {"canonical": "Шанхай", "country": "Китай", "scope": "foreign"},
    "shanghai": {"canonical": "Шанхай", "country": "Китай", "scope": "foreign"},
    "торонто": {"canonical": "Торонто", "country": "Канада", "scope": "foreign"},
    "toronto": {"canonical": "Торонто", "country": "Канада", "scope": "foreign"},
    "ванкувер": {"canonical": "Ванкувер", "country": "Канада", "scope": "foreign"},
    "vancouver": {"canonical": "Ванкувер", "country": "Канада", "scope": "foreign"},
}

# Если в тексте не нашлось ни города, ни страны — грубая догадка по языку
# документа. Для EN/ES конкретную страну не придумываем (слишком много
# вариантов), честно помечаем источник как иностранный без указания страны.
LANG_FALLBACK: Dict[str, dict] = {
    "ru": {"canonical": "Россия (по языку документа)", "scope": "domestic"},
    "en": {"canonical": "иностранный источник (язык: EN)", "scope": "foreign"},
    "es": {"canonical": "иностранный источник (язык: ES)", "scope": "foreign"},
}

CLIMATE: Dict[str, str] = {
    "холодный климат": "холодный", "cold climate": "холодный", "clima frío": "холодный",
    "clima frio": "холодный", "арктический": "холодный", "arctic": "холодный",
    "жаркий климат": "жаркий", "hot climate": "жаркий", "clima cálido": "жаркий",
    "clima calido": "жаркий", "тропический": "жаркий", "tropical": "жаркий",
}

# --- единицы измерения для извлечения числовых ограничений ------------------
UNITS = ["мг/л", "mg/l", "г/л", "g/l", "°c", "° c", "градус", "grados",
         "т/сут", "t/day", "ton/day", "%", "проц", "м3/ч", "m3/h", "л/мин", "l/min",
         "мпа", "mpa", "квт", "kw", "$/т", "usd/t", "руб/т"]

_norm_re = re.compile(r"\s+")


def _norm(s: str) -> str:
    return _norm_re.sub(" ", s.lower().strip())


# индекс формы -> id концепта (построен один раз при импорте)
_FORM_INDEX: Dict[str, str] = {}
for c in CONCEPTS:
    for f in c["forms"] + [c["canonical"]]:
        _FORM_INDEX[_norm(f)] = c["id"]

_BY_ID = {c["id"]: c for c in CONCEPTS}
DIRECTION_BY_CONCEPT: Dict[str, str] = {c["id"]: c.get("direction", "прочее") for c in CONCEPTS}
ALL_DIRECTIONS = sorted({c.get("direction", "прочее") for c in CONCEPTS})


def _stem(w: str) -> str:
    """Грубый стемминг для русских словоформ (печать/печати/печатью -> печат).
    Для латиницы/испанского возвращает слово как есть — там меньше вариативности
    в ключевых терминах домена."""
    if re.search(r"[а-яё]", w) and len(w) > 5:
        return w[:-2]
    return w


def canonicalize(text: str) -> List[Tuple[str, dict]]:
    """Находит в тексте все упоминания известных понятий (любой язык/форма,
    включая словоформы через грубый стемминг) и возвращает список
    (найденная_форма, concept). Длинные формы матчатся первыми, чтобы
    «кучное выщелачивание» не терялось за «выщелачивание»."""
    low = _norm(text)
    hits = []
    seen_concepts = set()
    forms_sorted = sorted(_FORM_INDEX.keys(), key=len, reverse=True)
    covered = [False] * len(low)
    # 1) точные вхождения форм (самые надёжные)
    for form in forms_sorted:
        start = 0
        while True:
            idx = low.find(form, start)
            if idx < 0:
                break
            end = idx + len(form)
            if not any(covered[idx:end]):
                before = low[idx - 1] if idx > 0 else " "
                after = low[end] if end < len(low) else " "
                if not before.isalnum() and not after.isalnum():
                    hits.append((form, _BY_ID[_FORM_INDEX[form]]))
                    seen_concepts.add(_FORM_INDEX[form])
                    for i in range(idx, end):
                        covered[i] = True
            start = idx + 1
    # 2) словоформы через стемминг многословных/однословных RU-терминов,
    # которые ещё не найдены точно (напр. «3д печати» -> форма «3д печать»)
    words = re.findall(r"[a-zа-яё0-9\-]+", low)
    text_stems = {_stem(w) for w in words}
    for form, cid in _FORM_INDEX.items():
        if cid in seen_concepts:
            continue
        form_words = form.split()
        if all(_stem(fw) in text_stems or fw in words for fw in form_words):
            hits.append((form, _BY_ID[cid]))
            seen_concepts.add(cid)
    return hits


def _geo_match(key: str, low: str) -> bool:
    """Ищет ключ города/страны в тексте с учётом русской морфологии
    («Норильске» должно матчиться с ключом «норильск»)."""
    if re.search(r"[а-яё]", key) and len(key) > 5:
        stem = re.escape(key[:-2])
        return re.search(rf"\b{stem}", low) is not None
    return re.search(rf"\b{re.escape(key)}\b", low) is not None


def find_geography(text: str) -> List[dict]:
    """Все упоминания географии в тексте: города (с привязкой к стране) и
    страны. Возвращает вперемешку, самые специфичные (города) — первыми."""
    low = _norm(text)
    cities, countries, out = [], [], []
    for key, meta in CITIES.items():
        if _geo_match(key, low):
            cities.append({"canonical": meta["canonical"], "scope": meta["scope"],
                          "kind": "city", "country": meta["country"]})
    for key, meta in GEOGRAPHY.items():
        if _geo_match(key, low):
            countries.append({"canonical": meta["canonical"], "scope": meta["scope"], "kind": "country"})
    out = cities + countries
    for key, canon in CLIMATE.items():
        if key in low:
            out.append({"canonical": canon, "scope": "climate", "kind": "climate"})
    seen, res = set(), []
    for g in out:
        if g["canonical"] not in seen:
            seen.add(g["canonical"]); res.append(g)
    return res


def geo_for_document(text: str, lang: str = "?") -> dict:
    """Выбирает ОДНУ, максимально конкретную географию документа: город, если
    найден; иначе страна; иначе — грубая догадка по языку документа (без
    домысливания конкретной страны для EN/ES). Возвращает {"canonical","scope"}
    либо None, если определить совсем нечего (текста мало/язык не определён)."""
    hits = find_geography(text)
    city = next((g for g in hits if g.get("kind") == "city"), None)
    if city:
        return {"canonical": f"{city['canonical']}, {city['country']}", "scope": city["scope"]}
    country = next((g for g in hits if g.get("kind") == "country"), None)
    if country:
        return {"canonical": country["canonical"], "scope": country["scope"]}
    if lang in LANG_FALLBACK:
        return dict(LANG_FALLBACK[lang])
    return None


_NUM_RE = re.compile(
    r"(?P<param>[a-zа-яё][a-zа-яё \-]{2,30}?)\s*[:\-]?\s*"
    r"(?P<op>≤|≥|<=|>=|<|>|=|не более|не менее|более|менее|от)?\s*"
    r"(?P<val>-?\d+[.,]?\d*)\s*"
    r"(?:(?:-\s*|до\s+)(?P<val2>-?\d+[.,]?\d*)\s*)?"
    r"(?P<unit>" + "|".join(re.escape(u) for u in UNITS) + r")",
    re.IGNORECASE | re.UNICODE,
)


def extract_constraints(text: str) -> List[dict]:
    """Эвристически находит числовые ограничения/диапазоны вида
    «сульфаты ≤300 мг/л», «температура: от 20 до 80 °C», «производительность
    от 100 т/сут». Не заменяет полноценный NLP, но покрывает частые паттерны
    отчётов и не требует моделей/сети."""
    out = []
    for m in _NUM_RE.finditer(text):
        param = m.group("param").strip(" .,:-")
        if len(param) < 3 or len(param) > 40:
            continue
        op = (m.group("op") or "=").strip()
        val = m.group("val").replace(",", ".")
        val2 = m.group("val2")
        unit = m.group("unit")
        item = {"param": param, "op": op, "value": val, "unit": unit,
                "raw": m.group(0).strip()}
        if val2:
            item["value_max"] = val2.replace(",", ".")
            item["op"] = "диапазон"
        out.append(item)
    return out[:12]
