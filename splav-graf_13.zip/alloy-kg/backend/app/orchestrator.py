"""Динамический оркестратор (RAG по графу знаний, построенному из ВСЕХ
загруженных документов).

Путь запроса, как в ТЗ:
  1. adapt   — LLM (если доступна) переформулирует запрос для поиска, либо
               сразу берутся ключевые слова/сущности (эвристика);
  2. parse   — сущности/география/числовые ограничения запроса (тот же
               словарь, что и при загрузке документов — единый граф);
  3. retrieve— поиск по фрагментам ВСЕХ документов (не top-1, а весь
               релевантный набор), затем отбор действительно подходящих;
  4. dedup   — по каждой сущности запроса — в скольких ИСТОЧНИКАХ она
               встречается (подсветка дублирования метода/географии);
  5. gaps    — комбинации сущностей запроса без единого подтверждающего
               источника — отдельный обязательный раздел ответа;
  6. synth   — ответ LLM строго по отобранным фрагментам, с цитатами и
               верификацией (источник, достоверность, дата, география)."""
import time
from typing import Dict, List, Optional

from . import db, tools
from .graph_store import Graph
from .llm import llm
import re

_CITE = re.compile(r"\[(\d+)\]")


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _split_why(text: str):
    if not text:
        return "", ""
    m = re.search(r"(?im)^\s*(?:«?\s*почему так\s*»?|почему именно так)\s*[:\-—.]?\s*", text)
    if m:
        return text[:m.start()].strip(), text[m.end():].strip()
    return text.strip(), ""


def _segments(main_text: str) -> List[dict]:
    segs = []
    for raw in [p for p in main_text.split("\n") if p.strip()]:
        html = _CITE.sub(lambda mm: f'<span class="cite" data-ev="ev{mm.group(1)}">[{mm.group(1)}]</span>',
                         _esc(raw))
        segs.append({"html": html})
    return segs


def run(query: str, con, geo_filter: Optional[str] = None) -> dict:
    t0 = time.time()
    trace = []

    def step(kind, tool, name, detail):
        trace.append({"kind": kind, "tool": tool, "name": name, "detail": detail})

    counts = db.counts(con)
    if counts["documents"] == 0:
        step("tool", "chunk_search", "Поиск по документам", "корпус пуст")
        msg = ("В базе пока нет загруженных документов. Загрузите файлы или ссылки — "
               "и я отвечу строго по их содержимому, с указанием источников.")
        return {"query": query, "adapted": {}, "trace": trace,
                "answer": {"segments": [{"html": _esc(msg)}], "why": ""},
                "evidence": [], "entities": [], "gaps": [], "dedup": [],
                "took_ms": int((time.time() - t0) * 1000)}

    # 1) адаптация запроса
    adapted = llm.adapt_query(query)
    search_query = adapted["search_query"]
    step("plan", "orchestrator" if adapted["adapted_by"] == "heuristic" else "llm",
         "Адаптация запроса",
         (f"переформулирован ({adapted['adapted_by']}): «{search_query}»"
          if search_query.strip().lower() != query.strip().lower() else
          f"запрос понятен, ключевые точки: {', '.join(adapted['key_points']) or '—'}"))

    # 2) сущности запроса (единый мультиязычный граф)
    qe = tools.query_entities(query)
    concepts, geo, constraints = qe["concepts"], qe["geography"], qe["constraints"]
    step("parse", "nlu", "Разбор сущностей запроса",
         f"понятия: {', '.join(c['canonical'] for c in concepts) or '—'} · "
         f"география: {', '.join(g['canonical'] for g in geo) or '—'} · "
         f"числовые условия: {len(constraints)}")

    # geo-фильтр (отечественная/зарубежная практика)
    doc_ids_filter = None
    if geo_filter in ("domestic", "foreign"):
        rows = con.execute("SELECT id FROM documents WHERE geo_scope=?", (geo_filter,)).fetchall()
        doc_ids_filter = [r["id"] for r in rows]
        step("tool", "geo_filter", "Фильтр по географии",
             f"{'отечественная' if geo_filter=='domestic' else 'зарубежная'} практика: "
             f"{len(doc_ids_filter)} документ(ов)")
        if not doc_ids_filter:
            msg = ("По выбранному географическому фильтру подходящих документов нет. "
                  "Снимите фильтр или загрузите документы этой географии.")
            return {"query": query, "adapted": adapted, "trace": trace,
                    "answer": {"segments": [{"html": _esc(msg)}], "why": ""},
                    "evidence": [], "entities": [], "gaps": [], "dedup": [],
                    "took_ms": int((time.time() - t0) * 1000)}

    # 3) retrieve — по ВСЕМ (или отфильтрованным) документам
    fragments = tools.chunk_search(search_query, con, top_k=12, doc_ids=doc_ids_filter)
    step("tool", "chunk_search", "Поиск по документам",
         f"проверено фрагментов по всем источникам, кандидатов: {len(fragments)}")

    lexical = [f for f in fragments if f["term_hits"] > 0]
    if lexical:
        doc_score = {}
        for f in lexical:
            doc_score[f["doc_id"]] = doc_score.get(f["doc_id"], 0) + f["term_hits"]
        top_score = max(doc_score.values())
        keep_docs = {d for d, sc in doc_score.items() if sc >= max(1, top_score * 0.5)}
        used = [f for f in fragments if f["doc_id"] in keep_docs]
        used.sort(key=lambda f: (-doc_score.get(f["doc_id"], 0), -f["score"]))
    else:
        used = fragments[:3]
    used = used[:8]
    for i, f in enumerate(used):
        f["n"] = i + 1
    n_sources = len({f["doc_id"] for f in used})
    step("tool", "rerank", "Отбор релевантных",
         (f"найдены совпадения слов — отобрано источников: {n_sources}"
          if lexical else "точных совпадений нет — показаны ближайшие по смыслу") +
         f"; фрагментов к синтезу: {len(used)}")

    # 4) dedup/частота — по каждому понятию запроса, в скольких источниках оно встречается
    concept_ids = [c["id"] for c in concepts]
    coverage = tools.entity_coverage(con, concept_ids) if concept_ids else {}
    dedup = []
    for c in concepts:
        cov = coverage.get(c["id"], {"doc_count": 0, "docs": []})
        dedup.append({"canonical": c["canonical"], "type": c["type"],
                      "doc_count": cov["doc_count"],
                      "docs": [d["title"] for d in cov["docs"]][:6]})
    if concept_ids:
        step("tool", "dedup_check", "Проверка дублирования",
             "; ".join(f"«{d['canonical']}» — в {d['doc_count']} источник(ах)" for d in dedup) or "—")

    # 5) пробелы знаний — отдельный обязательный раздел
    gaps = tools.detect_gaps(con, concepts, geo)
    step("tool", "gap_scan", "Поиск пробелов знаний", f"найдено пробелов: {len(gaps)}")

    # 6) синтез ответа строго по отобранным фрагментам
    raw = llm.answer_from_fragments(search_query, used)
    main_text, why = _split_why(raw)
    segments = _segments(main_text)
    step("synth", llm.label.split(" · ")[0].lower(), "Синтез ответа",
         f"ответ по {len(used)} фрагмент(ам) из {n_sources} источник(ов), с цитатами")

    # evidence — карточки фрагментов с верификацией
    evidence = []
    for f in used:
        rel = []
        if f["matched_terms"]:
            rel.append("совпали слова: " + ", ".join(f["matched_terms"][:5]))
        rel.append(f"смысловая близость {f['sem']:.2f}")
        evidence.append({
            "id": f"ev{f['n']}", "source_type": "document", "source_id": f["doc_id"],
            "title": f["title"], "snippet": f["text"], "matched_terms": f["matched_terms"],
            "relevance": "; ".join(rel),
            "verification": {
                "source": f.get("source") or f["title"],
                "confidence": f.get("confidence"),
                "added_at": f.get("added_at"),
                "geo_scope": f.get("geo_scope"),
                "lang": f.get("lang"),
            },
            "meta": [f["doc_type"], f["doc_id"]] + ([f["source"]] if f.get("source") else []),
        })

    # related entities/experts из графа (для правой панели)
    graph_data = db.load_graph(con)
    g = Graph(graph_data)
    entities = []
    seen_docs = set()
    for f in used:
        if f["doc_id"] not in seen_docs:
            seen_docs.add(f["doc_id"])
            entities.append({"type": "document", "label": f["title"], "sub": f["doc_type"],
                             "rel": "источник"})
    for c in concepts[:3]:
        for nb in g.neighbors(c["id"], limit=4):
            entities.append({"type": nb["type"], "label": nb["label"], "sub": nb["rel"],
                             "rel": c["canonical"]})

    return {
        "query": query, "adapted": adapted, "trace": trace,
        "answer": {"segments": segments, "why": why},
        "evidence": evidence, "entities": entities[:14], "gaps": gaps, "dedup": dedup,
        "took_ms": int((time.time() - t0) * 1000),
    }
