"""Слой БД: SQLite-схема кумулятивного графа знаний, построенного из ВСЕХ
загруженных документов. Каждый новый документ добавляет свой кусок графа
(сущности + связи + числовые ограничения), не затирая предыдущие — так
реализован пункт ТЗ «построение графа по документу -> добавление в общий граф»."""
import json
import os
import re
import sqlite3
import time
from typing import Dict, List, Optional

from .config import settings
from .embeddings import embedder

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents(
    id TEXT PRIMARY KEY, title TEXT, type TEXT, text TEXT,
    origin TEXT DEFAULT 'upload',      -- upload | url
    source TEXT,                       -- имя файла или URL
    has_text_layer INTEGER DEFAULT 1,
    images_count INTEGER DEFAULT 0,
    lang TEXT DEFAULT 'ru',            -- определённый язык документа (ru/en/es/?)
    geo_scope TEXT,                    -- domestic | foreign | NULL (не определено)
    geo_label TEXT,                    -- конкретная география: город, страна, либо по языку
    confidence REAL DEFAULT 0.6,       -- достоверность источника (эвристика + метаданные)
    added_at TEXT
);
CREATE TABLE IF NOT EXISTS chunks(
    id TEXT PRIMARY KEY, doc_id TEXT, ord INTEGER,
    text TEXT, start INTEGER, end INTEGER, vec TEXT
);
-- сущности графа: материал/процесс/оборудование/условие/география/время/команда
CREATE TABLE IF NOT EXISTS entities(
    id TEXT PRIMARY KEY,               -- canonical id (напр. process:leaching) или generated:<hash>
    type TEXT,                         -- material|process|equipment|condition|geography|time|team|domain
    canonical TEXT,                    -- каноническое имя (для отображения)
    concept_id TEXT                    -- ссылка на synonyms.CONCEPTS id, если распознано словарём
);
-- какие сущности встретились в каком документе (много-ко-многим + частота)
CREATE TABLE IF NOT EXISTS doc_entities(
    doc_id TEXT, entity_id TEXT, mentions INTEGER DEFAULT 1,
    PRIMARY KEY(doc_id, entity_id)
);
-- связи между сущностями, найденные в конкретном документе
CREATE TABLE IF NOT EXISTS relations(
    id TEXT PRIMARY KEY, doc_id TEXT,
    subj_id TEXT, predicate TEXT, obj_id TEXT, confidence REAL DEFAULT 0.5
);
-- числовые ограничения/диапазоны, привязанные к документу (и, если найдено, к сущности)
CREATE TABLE IF NOT EXISTS constraints(
    id TEXT PRIMARY KEY, doc_id TEXT, entity_id TEXT,
    param TEXT, op TEXT, value TEXT, value_max TEXT, unit TEXT, raw TEXT
);
CREATE TABLE IF NOT EXISTS vectors(key TEXT PRIMARY KEY, kind TEXT, ref TEXT, text TEXT, vec TEXT);
-- Вкладки чатов и история сообщений. Общие для всех, кто открывает
-- приложение (нет отдельных аккаунтов) — переживают обновление страницы
-- и видны с любого устройства, пока пользователь явно не закроет вкладку.
CREATE TABLE IF NOT EXISTS chats(
    id TEXT PRIMARY KEY, title TEXT, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS chat_messages(
    id TEXT PRIMARY KEY, chat_id TEXT, ord INTEGER,
    query TEXT, result_json TEXT, created_at TEXT
);
"""


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(settings.db_path)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


# Полный набор колонок для каждой таблицы (по текущей SCHEMA). CREATE TABLE
# IF NOT EXISTS не трогает уже существующую таблицу — если она была создана
# более ранней версией приложения с меньшим числом колонок, любой INSERT/UPDATE
# с новыми полями упадёт на "no column named X". Поэтому при каждом старте
# сверяем реальные колонки с этим списком и дописываем недостающие через
# ALTER TABLE ADD COLUMN (первичные ключи не трогаем — раз таблица существует,
# они у неё уже есть).
_TABLE_MIGRATIONS = {
    "documents": [
        ("origin", "TEXT DEFAULT 'upload'"),
        ("source", "TEXT"),
        ("has_text_layer", "INTEGER DEFAULT 1"),
        ("images_count", "INTEGER DEFAULT 0"),
        ("lang", "TEXT DEFAULT 'ru'"),
        ("geo_scope", "TEXT"),
        ("geo_label", "TEXT"),
        ("confidence", "REAL DEFAULT 0.6"),
        ("added_at", "TEXT"),
    ],
    "entities": [
        ("type", "TEXT"),
        ("canonical", "TEXT"),
        ("concept_id", "TEXT"),
    ],
    "doc_entities": [
        ("mentions", "INTEGER DEFAULT 1"),
    ],
    "relations": [
        ("doc_id", "TEXT"),
        ("subj_id", "TEXT"),
        ("predicate", "TEXT"),
        ("obj_id", "TEXT"),
        ("confidence", "REAL DEFAULT 0.5"),
    ],
    "constraints": [
        ("doc_id", "TEXT"),
        ("entity_id", "TEXT"),
        ("param", "TEXT"),
        ("op", "TEXT"),
        ("value", "TEXT"),
        ("value_max", "TEXT"),
        ("unit", "TEXT"),
        ("raw", "TEXT"),
    ],
    "chunks": [
        ("doc_id", "TEXT"),
        ("ord", "INTEGER"),
        ("text", "TEXT"),
        ("start", "INTEGER"),
        ("end", "INTEGER"),
        ("vec", "TEXT"),
    ],
    "vectors": [
        ("kind", "TEXT"),
        ("ref", "TEXT"),
        ("text", "TEXT"),
        ("vec", "TEXT"),
    ],
    "chats": [
        ("title", "TEXT"),
        ("created_at", "TEXT"),
        ("updated_at", "TEXT"),
    ],
    "chat_messages": [
        ("chat_id", "TEXT"),
        ("ord", "INTEGER"),
        ("query", "TEXT"),
        ("result_json", "TEXT"),
        ("created_at", "TEXT"),
    ],
}


def _migrate_table(con: sqlite3.Connection, table: str, col_defs: list):
    cols = {r["name"] for r in con.execute(f"PRAGMA table_info({table})")}
    if not cols:
        return  # таблицы ещё нет — её создаст executescript(SCHEMA), колонки уже верные
    for name, decl in col_defs:
        if name not in cols:
            con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")
    con.commit()


def init_db(force: bool = False):
    if force and os.path.exists(settings.db_path):
        os.remove(settings.db_path)
    con = connect()
    con.executescript(SCHEMA)
    con.commit()
    for table, col_defs in _TABLE_MIGRATIONS.items():
        _migrate_table(con, table, col_defs)
    con.close()


# --------------------------------------------------------------------------- #
#  Чанкинг текста (для семантического поиска и подсветки источника)
# --------------------------------------------------------------------------- #
def chunk_text(text: str, target: int = 480, overlap: int = 80):
    """Бьёт текст на перекрывающиеся фрагменты по границам абзацев/предложений.
    Возвращает список (chunk_text, start, end) с позициями в исходном тексте."""
    text = text or ""
    if not text.strip():
        return []
    paras, pos = [], 0
    for m in re.finditer(r"[^\n]+(?:\n(?!\n)[^\n]+)*", text):
        paras.append((m.group(0), m.start(), m.end()))
    chunks = []
    for ptext, pstart, pend in paras:
        if len(ptext) <= target:
            chunks.append((ptext, pstart, pend))
            continue
        sent_spans = [(mm.start(), mm.end()) for mm in re.finditer(r"[^.!?]+[.!?]*", ptext)
                      if mm.group(0).strip()]
        buf_s = buf_e = None
        for s, e in sent_spans:
            if buf_s is None:
                buf_s, buf_e = s, e
            elif e - buf_s > target:
                chunks.append((ptext[buf_s:buf_e], pstart + buf_s, pstart + buf_e))
                back = max(buf_e - overlap, buf_s)
                buf_s, buf_e = back, e
            else:
                buf_e = e
        if buf_s is not None:
            chunks.append((ptext[buf_s:buf_e], pstart + buf_s, pstart + buf_e))
    return [(t.strip(), s, e) for t, s, e in chunks if t.strip()]


def _reindex_doc_chunks(con: sqlite3.Connection, doc_id: str, title: str, text: str):
    con.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
    pieces = chunk_text(text)
    if not pieces:
        con.commit()
        return 0
    blobs = [f"{title}. {ptext}" if title else ptext for ptext, _, _ in pieces]
    vecs = embedder.embed(blobs)
    for i, ((ptext, start, end), v) in enumerate(zip(pieces, vecs)):
        con.execute(
            "INSERT OR REPLACE INTO chunks(id,doc_id,ord,text,start,end,vec) VALUES(?,?,?,?,?,?,?)",
            (f"{doc_id}#c{i}", doc_id, i, ptext, start, end, json.dumps(v)))
    con.commit()
    return len(pieces)


def _index_whole_doc(con: sqlite3.Connection, doc_id: str, title: str, text: str):
    blob = f"{title}. {text}".strip()
    vec = embedder.embed([blob])[0]
    con.execute(
        "INSERT OR REPLACE INTO vectors(key,kind,ref,text,vec) VALUES(?,?,?,?,?)",
        ("doc:" + doc_id, "document", doc_id, blob, json.dumps(vec)))


# --------------------------------------------------------------------------- #
#  Документы
# --------------------------------------------------------------------------- #
def add_document(con: sqlite3.Connection, doc: dict):
    """Вставляет/заменяет документ, переиндексирует его для поиска.
    Извлечение сущностей/связей/ограничений выполняется отдельно
    (см. extraction.py), т.к. может требовать вызова LLM."""
    con.execute(
        "INSERT OR REPLACE INTO documents"
        "(id,title,type,text,origin,source,has_text_layer,images_count,lang,geo_scope,geo_label,confidence,added_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (doc["id"], doc.get("title", ""), doc.get("type", "Документ"), doc.get("text", ""),
         doc.get("origin", "upload"), doc.get("source"),
         int(doc.get("has_text_layer", 1)), int(doc.get("images_count", 0)),
         doc.get("lang", "ru"), doc.get("geo_scope"), doc.get("geo_label"),
         float(doc.get("confidence", 0.6)), doc.get("added_at") or str(int(time.time()))))
    con.commit()
    _index_whole_doc(con, doc["id"], doc.get("title", ""), doc.get("text", ""))
    _reindex_doc_chunks(con, doc["id"], doc.get("title", ""), doc.get("text", ""))
    con.commit()


def list_documents(con: sqlite3.Connection) -> List[dict]:
    rows = con.execute(
        "SELECT id,title,type,origin,source,has_text_layer,images_count,lang,"
        "geo_scope,geo_label,confidence,added_at,length(text) AS chars "
        "FROM documents ORDER BY rowid DESC")
    return [dict(r) for r in rows]


def get_document(con: sqlite3.Connection, doc_id: str) -> Optional[dict]:
    row = con.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
    return dict(row) if row else None


def delete_document(con: sqlite3.Connection, doc_id: str) -> bool:
    cur = con.execute("DELETE FROM documents WHERE id=?", (doc_id,))
    con.execute("DELETE FROM vectors WHERE key=?", ("doc:" + doc_id,))
    con.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
    con.execute("DELETE FROM doc_entities WHERE doc_id=?", (doc_id,))
    con.execute("DELETE FROM relations WHERE doc_id=?", (doc_id,))
    con.execute("DELETE FROM constraints WHERE doc_id=?", (doc_id,))
    con.commit()
    return cur.rowcount > 0


# --------------------------------------------------------------------------- #
#  Граф: сущности / связи / ограничения (добавление куска графа документа)
# --------------------------------------------------------------------------- #
def upsert_entity(con: sqlite3.Connection, entity_id: str, etype: str, canonical: str,
                   concept_id: Optional[str] = None):
    con.execute("INSERT OR IGNORE INTO entities(id,type,canonical,concept_id) VALUES(?,?,?,?)",
                (entity_id, etype, canonical, concept_id))


def link_doc_entity(con: sqlite3.Connection, doc_id: str, entity_id: str, mentions: int = 1):
    row = con.execute("SELECT mentions FROM doc_entities WHERE doc_id=? AND entity_id=?",
                       (doc_id, entity_id)).fetchone()
    if row:
        con.execute("UPDATE doc_entities SET mentions=? WHERE doc_id=? AND entity_id=?",
                    (row["mentions"] + mentions, doc_id, entity_id))
    else:
        con.execute("INSERT INTO doc_entities(doc_id,entity_id,mentions) VALUES(?,?,?)",
                    (doc_id, entity_id, mentions))


def add_relation(con: sqlite3.Connection, doc_id: str, subj_id: str, predicate: str,
                  obj_id: str, confidence: float = 0.5):
    rid = f"{doc_id}#r{abs(hash((subj_id, predicate, obj_id))) % 100000}"
    con.execute(
        "INSERT OR REPLACE INTO relations(id,doc_id,subj_id,predicate,obj_id,confidence) "
        "VALUES(?,?,?,?,?,?)",
        (rid, doc_id, subj_id, predicate, obj_id, confidence))


def add_constraint(con: sqlite3.Connection, doc_id: str, entity_id: Optional[str], c: dict):
    cid = f"{doc_id}#c{abs(hash((c['param'], c['value'], c.get('unit')))) % 100000}"
    con.execute(
        "INSERT OR REPLACE INTO constraints(id,doc_id,entity_id,param,op,value,value_max,unit,raw) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (cid, doc_id, entity_id, c["param"], c["op"], c["value"],
         c.get("value_max"), c.get("unit"), c.get("raw")))


def clear_graph_for_doc(con: sqlite3.Connection, doc_id: str):
    con.execute("DELETE FROM doc_entities WHERE doc_id=?", (doc_id,))
    con.execute("DELETE FROM relations WHERE doc_id=?", (doc_id,))
    con.execute("DELETE FROM constraints WHERE doc_id=?", (doc_id,))


def load_graph(con: sqlite3.Connection) -> dict:
    """Загружает весь кумулятивный граф (по всем документам) в память."""
    entities = {r["id"]: dict(r) for r in con.execute("SELECT * FROM entities")}
    doc_entities = [dict(r) for r in con.execute("SELECT * FROM doc_entities")]
    relations = [dict(r) for r in con.execute("SELECT * FROM relations")]
    constraints = [dict(r) for r in con.execute("SELECT * FROM constraints")]
    documents = {r["id"]: dict(r) for r in con.execute("SELECT * FROM documents")}
    return {"entities": entities, "doc_entities": doc_entities,
            "relations": relations, "constraints": constraints, "documents": documents}


def counts(con: sqlite3.Connection) -> dict:
    def n(table):
        return con.execute(f"SELECT COUNT(*) c FROM {table}").fetchone()["c"]
    return {"documents": n("documents"), "entities": n("entities"),
            "relations": n("relations"), "constraints": n("constraints"),
            "chunks": n("chunks")}

# --------------------------------------------------------------------------- #
#  Чаты: общее хранилище вкладок и истории сообщений (без аккаунтов —
#  видно всем, кто открывает приложение, с любого устройства; переживает
#  обновление страницы; удаляется только явным закрытием вкладки).
# --------------------------------------------------------------------------- #
def create_chat(con: sqlite3.Connection, chat_id: str, title: str):
    now = str(int(time.time()))
    con.execute("INSERT INTO chats(id,title,created_at,updated_at) VALUES(?,?,?,?)",
                (chat_id, title, now, now))
    con.commit()


def list_chats(con: sqlite3.Connection) -> List[dict]:
    rows = con.execute(
        "SELECT c.id, c.title, c.created_at, c.updated_at, "
        "(SELECT COUNT(*) FROM chat_messages m WHERE m.chat_id=c.id) AS msg_count "
        "FROM chats c ORDER BY c.created_at ASC")
    return [dict(r) for r in rows]


def get_chat(con: sqlite3.Connection, chat_id: str) -> Optional[dict]:
    row = con.execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()
    return dict(row) if row else None


def rename_chat(con: sqlite3.Connection, chat_id: str, title: str):
    con.execute("UPDATE chats SET title=?, updated_at=? WHERE id=?",
                (title, str(int(time.time())), chat_id))
    con.commit()


def delete_chat(con: sqlite3.Connection, chat_id: str) -> bool:
    cur = con.execute("DELETE FROM chats WHERE id=?", (chat_id,))
    con.execute("DELETE FROM chat_messages WHERE chat_id=?", (chat_id,))
    con.commit()
    return cur.rowcount > 0


def add_chat_message(con: sqlite3.Connection, chat_id: str, msg_id: str,
                      query: str, result: dict):
    ord_row = con.execute(
        "SELECT COALESCE(MAX(ord), -1) + 1 AS n FROM chat_messages WHERE chat_id=?",
        (chat_id,)).fetchone()
    con.execute(
        "INSERT INTO chat_messages(id,chat_id,ord,query,result_json,created_at) "
        "VALUES(?,?,?,?,?,?)",
        (msg_id, chat_id, ord_row["n"], query, json.dumps(result, ensure_ascii=False),
         str(int(time.time()))))
    con.execute("UPDATE chats SET updated_at=? WHERE id=?",
                (str(int(time.time())), chat_id))
    con.commit()


def list_chat_messages(con: sqlite3.Connection, chat_id: str) -> List[dict]:
    rows = con.execute(
        "SELECT id, query, result_json, created_at FROM chat_messages "
        "WHERE chat_id=? ORDER BY ord ASC", (chat_id,))
    out = []
    for r in rows:
        out.append({"id": r["id"], "query": r["query"],
                    "result": json.loads(r["result_json"]), "created_at": r["created_at"]})
    return out
