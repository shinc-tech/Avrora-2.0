"""Эмбеддинги. По умолчанию — детерминированный офлайн-хэш (0 зависимостей,
0 загрузок), пригодный для лексически близких запросов. При EMBEDDING_BACKEND=st
используется sentence-transformers (например BAAI/bge-m3) — заметно лучше
ловит смысловую близость и хорошо работает мультиязычно (RU/EN/ES)."""
import hashlib
import math
from typing import List

from .config import settings


class LocalEmbedder:
    """Хэшированные char-триграммы -> плотный вектор фиксированной размерности.
    Не требует моделей/сети; ловит лексическое сходство, слабо — семантику."""
    def __init__(self, dim: int = 512):
        self.dim = dim

    def embed(self, texts: List[str]) -> List[List[float]]:
        return [self._embed_one(t or "") for t in texts]

    def _embed_one(self, text: str) -> List[float]:
        v = [0.0] * self.dim
        text = text.lower()
        grams = [text[i:i + 3] for i in range(max(len(text) - 2, 1))] or [text]
        for g in grams:
            h = int(hashlib.md5(g.encode("utf-8")).hexdigest(), 16)
            v[h % self.dim] += 1.0
        norm = math.sqrt(sum(x * x for x in v)) or 1.0
        return [x / norm for x in v]


class STEmbedder:
    """Обёртка над sentence-transformers (опционально; ставится отдельно)."""
    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer
        self._model = SentenceTransformer(model_name)

    def embed(self, texts: List[str]) -> List[List[float]]:
        vecs = self._model.encode(texts, normalize_embeddings=True)
        return [v.tolist() for v in vecs]


def get_embedder():
    if settings.embedding_backend == "st":
        try:
            return STEmbedder(settings.st_model)
        except Exception as e:
            print(f"[embeddings] sentence-transformers недоступен ({e}); откат на local")
    return LocalEmbedder(settings.embedding_dim)


def cosine(a: List[float], b: List[float]) -> float:
    if len(a) != len(b):
        n = min(len(a), len(b))
        a, b = a[:n], b[:n]
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(x * x for x in b)) or 1.0
    return dot / (na * nb)


embedder = get_embedder()
