"""Работа с кумулятивным графом знаний (все документы вместе): соседи узла,
цепочки материал->процесс->оборудование->результат, сводка для дашборда и
компактное представление для визуализации в интерфейсе."""
from collections import defaultdict
from typing import Dict, List, Optional

REL_LABEL = {
    "исследован_в_процессе": "исследован в процессе",
    "выполняется_на": "выполняется на",
    "применялся_в": "применялся в",
    "период": "период",
    "исследовала": "исследовала",
}


class Graph:
    def __init__(self, data: dict):
        self.entities = data["entities"]           # id -> {id,type,canonical,concept_id}
        self.documents = data["documents"]          # id -> document row
        self.relations = data["relations"]          # list of {doc_id,subj_id,predicate,obj_id,confidence}
        self.constraints = data["constraints"]
        self.doc_entities = data["doc_entities"]    # list of {doc_id,entity_id,mentions}

        self.out_edges: Dict[str, List[dict]] = defaultdict(list)
        self.in_edges: Dict[str, List[dict]] = defaultdict(list)
        for r in self.relations:
            self.out_edges[r["subj_id"]].append(r)
            self.in_edges[r["obj_id"]].append(r)

        self.entity_docs: Dict[str, set] = defaultdict(set)
        for de in self.doc_entities:
            self.entity_docs[de["entity_id"]].add(de["doc_id"])

    def coverage(self, entity_id: str) -> int:
        return len(self.entity_docs.get(entity_id, ()))

    def neighbors(self, entity_id: str, limit: int = 12) -> List[dict]:
        out = []
        for r in self.out_edges.get(entity_id, [])[:limit]:
            e = self.entities.get(r["obj_id"])
            if e:
                out.append({"type": e["type"], "label": e["canonical"],
                           "rel": REL_LABEL.get(r["predicate"], r["predicate"]),
                           "doc_id": r["doc_id"], "direction": "out"})
        for r in self.in_edges.get(entity_id, [])[:limit]:
            e = self.entities.get(r["subj_id"])
            if e:
                out.append({"type": e["type"], "label": e["canonical"],
                           "rel": REL_LABEL.get(r["predicate"], r["predicate"]),
                           "doc_id": r["doc_id"], "direction": "in"})
        return out[:limit]

    def chain_from(self, entity_id: str, max_hops: int = 3) -> List[List[str]]:
        """Цепочки от узла (напр. материал -> процесс -> оборудование)."""
        chains = []

        def dfs(node, path, hops):
            if hops >= max_hops:
                chains.append(path)
                return
            edges = self.out_edges.get(node, [])
            if not edges:
                chains.append(path)
                return
            for r in edges[:3]:
                e = self.entities.get(r["obj_id"])
                if not e or r["obj_id"] in [p.split("|")[0] for p in path]:
                    continue
                dfs(r["obj_id"], path + [f"{r['obj_id']}|{e['canonical']}|{r['predicate']}"], hops + 1)

        dfs(entity_id, [f"{entity_id}|{self.entities.get(entity_id,{}).get('canonical','?')}|start"], 0)
        return chains[:6]

    def related_experts(self, entity_id: str) -> List[dict]:
        out = []
        for r in self.relations:
            if r["obj_id"] == entity_id or r["subj_id"] == entity_id:
                other = r["subj_id"] if r["obj_id"] == entity_id else r["obj_id"]
                e = self.entities.get(other)
                if e and e["type"] == "team":
                    out.append({"label": e["canonical"], "doc_id": r["doc_id"]})
        return out[:5]

    def summary(self) -> dict:
        by_type = defaultdict(int)
        for e in self.entities.values():
            by_type[e["type"]] += 1
        top = sorted(self.entities.values(), key=lambda e: -self.coverage(e["id"]))[:15]
        return {
            "by_type": dict(by_type),
            "documents": len(self.documents),
            "relations": len(self.relations),
            "top_entities": [{"id": e["id"], "type": e["type"], "canonical": e["canonical"],
                              "doc_count": self.coverage(e["id"])} for e in top
                             if self.coverage(e["id"]) > 0],
        }

    def to_viz(self, entity_ids: List[str], max_nodes: int = 24) -> dict:
        """Компактный граф для отрисовки: узлы + рёбра вокруг заданных сущностей."""
        node_ids = set(entity_ids)
        edges = []
        for eid in list(entity_ids):
            for r in self.out_edges.get(eid, [])[:4]:
                if r["obj_id"] in self.entities:
                    node_ids.add(r["obj_id"])
                    edges.append({"from": eid, "to": r["obj_id"],
                                 "label": REL_LABEL.get(r["predicate"], r["predicate"])})
            for r in self.in_edges.get(eid, [])[:4]:
                if r["subj_id"] in self.entities:
                    node_ids.add(r["subj_id"])
                    edges.append({"from": r["subj_id"], "to": eid,
                                 "label": REL_LABEL.get(r["predicate"], r["predicate"])})
        node_ids = list(node_ids)[:max_nodes]
        nodes = [{"id": nid, "type": self.entities[nid]["type"],
                 "label": self.entities[nid]["canonical"],
                 "doc_count": self.coverage(nid)} for nid in node_ids if nid in self.entities]
        edges = [e for e in edges if e["from"] in node_ids and e["to"] in node_ids]
        return {"nodes": nodes, "edges": edges}
