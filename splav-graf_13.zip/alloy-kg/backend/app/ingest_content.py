"""Извлечение текстового слоя из загруженных документов и онлайн-ресурсов.
Поддерживаются только источники с текстовым слоем (не картинкой): PDF, DOCX,
PPTX, HTML-страницы, обычный текст, ZIP-архивы (распаковываются, каждый
поддерживаемый файл внутри становится отдельным документом). Изображения —
медиа-объекты, не распознаются (OCR в системе намеренно не выполняется)."""
import os
import zipfile
from dataclasses import dataclass, field
from typing import List
from urllib.parse import urlparse

import requests

TEXT_EXT = {".txt", ".md", ".markdown", ".csv", ".tsv", ".json"}
HTML_EXT = {".html", ".htm"}
PDF_EXT = {".pdf"}
DOCX_EXT = {".docx"}
PPTX_EXT = {".pptx"}
ZIP_EXT = {".zip"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp", ".gif"}
SUPPORTED_EXT = TEXT_EXT | HTML_EXT | PDF_EXT | DOCX_EXT | PPTX_EXT | ZIP_EXT


@dataclass
class Extracted:
    kind: str
    text: str
    has_text_layer: bool
    pages: int = 1
    images_count: int = 0
    title: str = ""
    reason: str = ""
    images: List[str] = field(default_factory=list)


class ExtractError(RuntimeError):
    pass


def _read_text_file(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    return raw.decode("utf-8", errors="replace")


def _extract_pdf(path: str) -> Extracted:
    try:
        from pypdf import PdfReader
    except ImportError as e:
        raise ExtractError("pypdf не установлен") from e
    reader = PdfReader(path)
    pages = len(reader.pages)
    chunks, n_images = [], 0
    for pg in reader.pages:
        try:
            chunks.append(pg.extract_text() or "")
        except Exception:
            chunks.append("")
        try:
            n_images += len(pg.images)
        except Exception:
            pass
    text = "\n".join(chunks).strip()
    has_text = len(text) >= 20
    reason = (f"текстовый слой найден ({len(text)} симв., {pages} стр.)" if has_text
              else f"текстовый слой не найден или пуст ({pages} стр.) — похоже, "
                   "страницы отсканированы как картинки; OCR в системе не выполняется")
    return Extracted(kind="pdf", text=text, has_text_layer=has_text, pages=pages,
                     images_count=n_images, reason=reason)


def _extract_docx(path: str) -> Extracted:
    try:
        import docx
    except ImportError as e:
        raise ExtractError("python-docx не установлен") from e
    d = docx.Document(path)
    parts = [p.text for p in d.paragraphs if p.text.strip()]
    for tbl in d.tables:
        for row in tbl.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                parts.append(" | ".join(cells))
    text = "\n".join(parts).strip()
    n_images = 0
    try:
        n_images = sum(1 for r in d.part.rels.values() if "image" in r.reltype)
    except Exception:
        pass
    has_text = len(text) > 0
    reason = (f"текстовый слой найден ({len(text)} симв.)" if has_text
              else "документ Word не содержит текста")
    return Extracted(kind="docx", text=text, has_text_layer=has_text,
                     images_count=n_images, reason=reason)


def _extract_pptx(path: str) -> Extracted:
    try:
        from pptx import Presentation
    except ImportError as e:
        raise ExtractError("python-pptx не установлен") from e
    try:
        prs = Presentation(path)
    except Exception as e:
        raise ExtractError(f"не удалось разобрать PPTX: {e}") from e
    parts, n_images = [], 0
    n_slides = len(prs.slides._sldIdLst)
    for i, slide in enumerate(prs.slides, 1):
        slide_parts = []
        for shape in slide.shapes:
            try:
                if shape.has_text_frame and shape.text_frame.text.strip():
                    slide_parts.append(shape.text_frame.text.strip())
                if shape.has_table:
                    for row in shape.table.rows:
                        cells = [c.text.strip() for c in row.cells if c.text.strip()]
                        if cells:
                            slide_parts.append(" | ".join(cells))
                if shape.shape_type == 13:  # MSO_SHAPE_TYPE.PICTURE
                    n_images += 1
            except Exception:
                continue
        try:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
                slide_parts.append("Заметки: " + slide.notes_slide.notes_text_frame.text.strip())
        except Exception:
            pass
        if slide_parts:
            parts.append(f"[Слайд {i}] " + " / ".join(slide_parts))
    text = "\n".join(parts).strip()
    has_text = len(text) > 0
    reason = (f"текстовый слой найден ({len(text)} симв., {n_slides} слайд(ов))" if has_text
              else "презентация не содержит текста (только изображения)")
    return Extracted(kind="pptx", text=text, has_text_layer=has_text,
                     pages=n_slides, images_count=n_images, reason=reason)


def extract_zip(path: str):
    """Распаковывает архив и извлекает текст из каждого поддерживаемого файла
    внутри. Возвращает список (member_name, Extracted|None, error|None)."""
    try:
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile as e:
        raise ExtractError(f"повреждённый ZIP-архив: {e}") from e
    import tempfile
    out = []
    with zf:
        names = [n for n in zf.namelist() if not n.endswith("/") and "__MACOSX" not in n]
        if not names:
            raise ExtractError("архив пуст")
        base_supported = SUPPORTED_EXT - ZIP_EXT
        for name in names[:200]:  # защита от архивов с тысячами файлов
            ext = os.path.splitext(name)[1].lower()
            if ext not in base_supported:
                out.append((name, None, f"формат «{ext or 'без расширения'}» не поддерживается — пропущен"))
                continue
            try:
                data = zf.read(name)
            except Exception as e:
                out.append((name, None, f"не удалось прочитать файл из архива: {e}"))
                continue
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
                    tmp.write(data)
                    tmp_path = tmp.name
                out.append((name, extract_local_file(tmp_path, name), None))
            except ExtractError as e:
                out.append((name, None, str(e)))
            except Exception as e:
                out.append((name, None, f"ошибка обработки: {e}"))
            finally:
                if tmp_path:
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
    return out


def _extract_text(path: str) -> Extracted:
    text = _read_text_file(path)
    return Extracted(kind="text", text=text, has_text_layer=bool(text.strip()),
                     reason="текстовый файл")


def _extract_html_bytes(html: str) -> Extracted:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    title = (soup.title.string.strip() if soup.title and soup.title.string else "")
    text = soup.get_text("\n")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    text = "\n".join(lines)
    imgs = [img.get("src") for img in soup.find_all("img") if img.get("src")]
    has_text = len(text) >= 20
    reason = (f"текстовый слой страницы извлечён ({len(text)} симв.)" if has_text
              else "на странице не найдено текстового содержимого")
    return Extracted(kind="html", text=text, has_text_layer=has_text, title=title,
                     images_count=len(imgs), images=imgs[:50], reason=reason)


def extract_local_file(path: str, filename: str) -> Extracted:
    ext = os.path.splitext(filename)[1].lower()
    if ext in PDF_EXT:
        return _extract_pdf(path)
    if ext in DOCX_EXT:
        return _extract_docx(path)
    if ext in PPTX_EXT:
        return _extract_pptx(path)
    if ext in HTML_EXT:
        return _extract_html_bytes(_read_text_file(path))
    if ext in TEXT_EXT:
        return _extract_text(path)
    if ext in IMAGE_EXT:
        return Extracted(kind="image", text="", has_text_layer=False, images_count=1,
                         reason="изображение без текстового слоя — OCR не выполняется; "
                                "загрузите версию с текстом (PDF/DOCX/TXT) или ссылку")
    raise ExtractError(f"неподдерживаемый формат «{ext or 'без расширения'}». "
                       f"Поддерживаются: PDF, DOCX, HTML, TXT/MD/CSV/JSON")


_UA = "Mozilla/5.0 (compatible; SplavGraf/1.0; +document-ingest)"


def extract_url(url: str, timeout: int = 20) -> Extracted:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ExtractError("поддерживаются только http/https ссылки")
    try:
        resp = requests.get(url, headers={"User-Agent": _UA}, timeout=timeout)
        resp.raise_for_status()
    except requests.RequestException as e:
        raise ExtractError(f"не удалось загрузить ссылку: {e}") from e

    ctype = (resp.headers.get("Content-Type") or "").lower()
    content = resp.content[:25 * 1024 * 1024]

    if "application/pdf" in ctype or parsed.path.lower().endswith(".pdf"):
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp.write(content); tmp_path = tmp.name
        try:
            ext = _extract_pdf(tmp_path)
        finally:
            os.unlink(tmp_path)
        ext.title = parsed.path.rsplit("/", 1)[-1] or url
        return ext

    if "officedocument.wordprocessingml" in ctype or parsed.path.lower().endswith(".docx"):
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
            tmp.write(content); tmp_path = tmp.name
        try:
            ext = _extract_docx(tmp_path)
        finally:
            os.unlink(tmp_path)
        ext.title = parsed.path.rsplit("/", 1)[-1] or url
        return ext

    try:
        html = content.decode(resp.encoding or "utf-8", errors="replace")
    except Exception:
        html = content.decode("utf-8", errors="replace")
    return _extract_html_bytes(html)
