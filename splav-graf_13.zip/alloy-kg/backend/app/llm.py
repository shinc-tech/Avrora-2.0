"""LLM-доступ. Провайдер — любой OpenAI-совместимый эндпоинт (тестовый —
Qwen3 через Yandex AI Studio). Без ключа все функции работают через
детерминированные офлайн-заглушки (эвристика), чтобы система была
демонстрируема без внешних зависимостей — но качество синтеза и извлечения
вне словаря заметно ниже, это явно помечается в ответе (label модели)."""
import json
import re
from typing import List, Optional

from .config import settings

ANSWER_SYS = (
    "Ты — аналитик, отвечающий на вопрос СТРОГО по предоставленным фрагментам "
    "документов. Правила:\n"
    "1. Используй ТОЛЬКО факты из фрагментов. Ничего не придумывай.\n"
    "2. После каждого утверждения ставь ссылку на номер фрагмента: [1], [2].\n"
    "3. Если фрагменты противоречат друг другу (разные цифры/выводы по одному "
    "и тому же) — явно укажи оба значения со ссылками, не выбирай одно молча.\n"
    "4. Если во фрагментах нет ответа — честно напиши, что данных нет, и укажи "
    "ближайшее найденное.\n"
    "5. В конце добавь абзац «Почему так»: на основе скольких источников сделан "
    "вывод и есть ли расхождения.\n"
    "6. Пиши по-русски, кратко, без Markdown-заголовков."
)

QUERY_ADAPT_SYS = (
    "Ты нормализуешь поисковый запрос для системы поиска по техническим "
    "документам о металлургии/материаловедении. Верни JSON: "
    '{"search_query":"переформулированный запрос для поиска","key_points":["..."]}. '
    "search_query — краткий, по существу, на русском. key_points — 2-5 ключевых "
    "терминов/сущностей запроса. Если запрос уже чёткий — верни его почти как есть."
)


def _fragments_block(fragments: List[dict]) -> str:
    out = []
    for f in fragments:
        head = f"[{f['n']}] {f.get('title','')} ({f.get('doc_type','документ')})"
        out.append(head + "\n" + (f.get("text") or "").strip())
    return "\n\n".join(out)


class LLM:
    def __init__(self):
        self.available = settings.llm_available
        self._client = None
        if self.available:
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=settings.yandex_api_key,
                                      base_url=settings.yandex_base_url)
            except Exception as e:
                print(f"[llm] OpenAI SDK init failed ({e}); using stub")
                self.available = False

    @property
    def label(self) -> str:
        return f"{settings.yandex_model} · Yandex" if self.available else "Заглушка LLM (offline)"

    def complete(self, system: str, user: str, json_mode: bool = False) -> str:
        if self.available:
            kwargs = {}
            if json_mode:
                kwargs["response_format"] = {"type": "json_object"}
            resp = self._client.chat.completions.create(
                model=settings.model_uri,
                messages=[{"role": "system", "content": system},
                          {"role": "user", "content": user}],
                temperature=0.1, max_tokens=1100, **kwargs)
            return resp.choices[0].message.content
        return self._stub(system, user, json_mode)

    def adapt_query(self, query: str) -> dict:
        """Опциональная LLM-адаптация запроса. Без ключа — эвристика
        (значимые слова + известные термины словаря), без домыслов."""
        from . import synonyms, tools
        if self.available:
            try:
                raw = self.complete(QUERY_ADAPT_SYS, query, json_mode=True)
                data = json.loads(raw)
                if data.get("search_query"):
                    return {"search_query": data["search_query"],
                            "key_points": data.get("key_points", [])[:5],
                            "adapted_by": "llm"}
            except Exception as e:
                print(f"[llm] query adaptation failed ({e}); using heuristic")
        terms = tools._terms(query)
        known = [c["canonical"] for _, c in synonyms.canonicalize(query)]
        return {"search_query": query, "key_points": (known or terms)[:5], "adapted_by": "heuristic"}

    def answer_from_fragments(self, query: str, fragments: List[dict]) -> str:
        if not fragments:
            return ("В загруженных документах не нашлось фрагментов, относящихся к запросу. "
                    "Загрузите документы или ссылки по этой теме и повторите вопрос.\n"
                    "Почему так: поиск по корпусу не дал релевантных совпадений.")
        if self.available:
            user = "Вопрос: " + query + "\n\nФрагменты документов:\n" + _fragments_block(fragments)
            try:
                return self.complete(ANSWER_SYS, user, json_mode=False)
            except Exception as e:
                print(f"[llm] answer failed ({e}); using extractive stub")
        return _extractive_answer(query, fragments)

    def _stub(self, system: str, user: str, json_mode: bool) -> str:
        if json_mode:
            return json.dumps({"entities": [], "relations": []}, ensure_ascii=False)
        return "Готово."


_SENT = re.compile(r"[^.!?\n]+[.!?]?", re.UNICODE)


def _extractive_answer(query: str, fragments: List[dict]) -> str:
    from .tools import _terms, _word_hits
    terms = _terms(query)
    picked, any_lexical = [], False
    for f in fragments:
        text = (f.get("text") or "").strip()
        best = None
        for m in _SENT.finditer(text):
            s = m.group(0).strip()
            if not s:
                continue
            hits = len(_word_hits(terms, s.lower()))
            if hits and (best is None or hits > best[0]):
                best = (hits, s)
        if best:
            any_lexical = True
            picked.append((f["n"], best[1]))
        else:
            first = next((mm.group(0).strip() for mm in _SENT.finditer(text)
                          if mm.group(0).strip()), text[:200])
            picked.append((f["n"], first))

    lines = ["По загруженным документам найдено следующее:" if any_lexical else
             "Прямых совпадений по словам запроса в документах нет; ниже — "
             "наиболее близкие по смыслу фрагменты:"]
    for n, sent in picked[:5]:
        sent = sent if sent.endswith((".", "!", "?")) else sent + "."
        lines.append(f"\u2022 {sent} [{n}]")
    why = ("Почему так: ответ собран из фрагментов, найденных поиском по корпусу " +
           (f"({len({p[0] for p in picked})} источник(ов)). " if picked else ". ") +
           ("Подсвечены предложения со словами запроса." if any_lexical else
            "Точных словесных совпадений не было — показаны ближайшие по смыслу места."))
    return "\n".join(lines) + "\n" + why


llm = LLM()
