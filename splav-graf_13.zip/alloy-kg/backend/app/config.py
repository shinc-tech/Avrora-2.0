"""Настройки приложения. Всё заменяемое — через переменные окружения."""
import os
from dataclasses import dataclass


@dataclass
class Settings:
    # --- LLM (OpenAI-совместимый эндпоинт; тестовый провайдер — Qwen3 через Yandex) ---
    yandex_api_key: str = os.getenv("YANDEX_API_KEY", "")
    yandex_base_url: str = os.getenv("YANDEX_BASE_URL", "https://llm.api.cloud.yandex.net/v1")
    yandex_model: str = os.getenv("YANDEX_MODEL", "qwen3-235b-a22b-fp8")
    yandex_folder_id: str = os.getenv("YANDEX_FOLDER_ID", "")

    # --- Embeddings: 'local' (офлайн, без загрузок) | 'st' (sentence-transformers) ---
    embedding_backend: str = os.getenv("EMBEDDING_BACKEND", "local")
    st_model: str = os.getenv("ST_MODEL", "BAAI/bge-m3")
    embedding_dim: int = int(os.getenv("EMBEDDING_DIM", "512"))

    # --- storage ---
    data_dir: str = os.getenv("DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "data"))
    db_path: str = ""
    uploads_dir: str = ""
    reports_dir: str = ""

    # --- ingest ---
    fetch_max_mb: int = int(os.getenv("FETCH_MAX_MB", "25"))

    # --- извлечение сущностей при загрузке документа: auto -> LLM если есть ключ,
    # иначе эвристика (регулярки + словарь синонимов) ---
    extract_mode: str = os.getenv("EXTRACT_MODE", "auto")

    # --- Self-ping: не даёт бесплатному Replit "заснуть" от простоя ---
    # 0/off = отключено. Явный SELF_PING_URL имеет приоритет над автоопределением
    # через переменные окружения Replit (REPLIT_DOMAINS).
    self_ping_minutes: int = int(os.getenv("SELF_PING_MINUTES", "4"))
    self_ping_url: str = os.getenv("SELF_PING_URL", "")

    def __post_init__(self):
        self.data_dir = os.path.abspath(self.data_dir)
        os.makedirs(self.data_dir, exist_ok=True)
        self.db_path = os.path.join(self.data_dir, "kg.sqlite")
        self.uploads_dir = os.path.join(self.data_dir, "uploads")
        self.reports_dir = os.path.join(self.data_dir, "reports")
        os.makedirs(self.uploads_dir, exist_ok=True)
        os.makedirs(self.reports_dir, exist_ok=True)

    @property
    def llm_available(self) -> bool:
        return bool(self.yandex_api_key)

    @property
    def model_uri(self) -> str:
        if self.yandex_folder_id:
            return f"gpt://{self.yandex_folder_id}/{self.yandex_model}/latest"
        return self.yandex_model

    @property
    def extraction_llm_enabled(self) -> bool:
        if self.extract_mode == "on":
            return True
        if self.extract_mode == "off":
            return False
        return self.llm_available


settings = Settings()
