#!/usr/bin/env bash
# Сплав-Граф — local launch. Serves API + frontend on http://localhost:8000
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -q -r requirements.txt

# Optional: real LLM. Without these, an offline stub is used so the system still runs.
#   export YANDEX_API_KEY=...        # API key of a service account (role ai.languageModels.user)
#   export YANDEX_FOLDER_ID=...      # folder where the service account lives
#   export YANDEX_MODEL=qwen3-235b-a22b-fp8
# Optional: real multilingual embeddings instead of the offline hashing embedder:
#   export EMBEDDING_BACKEND=st && export ST_MODEL=BAAI/bge-m3

exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
