/* Сплав-Граф — фронтенд. Работает с бэкендом FastAPI; если бэкенд недоступен
   (открыт как локальный файл), переходит в честный демо-режим без RAG/графа
   (эти функции требуют серверного состояния — не подделываются в браузере). */

const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const escapeHtml = s => (s||"").replace(/[&<>"]/g, m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
const sleep = ms => new Promise(r=>setTimeout(r,ms));
const fmtDate = ts => { if(!ts) return "—"; const d=new Date(parseInt(ts,10)*1000); return isNaN(d)?"—":d.toLocaleDateString("ru-RU"); };
const fmtPct = v => v==null? "—" : Math.round(v*100)+"%";

/* ---------------- backend bridge ------------------------------ */
let MOCK=false, LAST_HEALTH=null;

async function api(path, opts){
  let r;
  try{ r = await fetch(path, opts); }
  catch(e){ throw new Error("запрос не дошёл до сервера: "+(e&&e.message?e.message:e)); }
  let body=null;
  try{ body = await r.json(); }catch(e){ /* тело не JSON — обработаем ниже */ }
  if(!r.ok){
    const msg = (body && (body.message||body.detail)) || `ошибка сервера (${r.status})`;
    throw new Error(msg);
  }
  return body;
}
async function detectBackend(){
  try{
    LAST_HEALTH = await api("/api/health");
    MOCK=false;
    $("#statusDot").classList.remove("off");
    $("#statusModel").textContent = LAST_HEALTH.llm_mock ? "LLM: заглушка (офлайн)" : "LLM: "+LAST_HEALTH.llm;
  }catch(e){
    MOCK=true; LAST_HEALTH=null;
    $("#statusDot").classList.add("off");
    $("#statusModel").textContent = "Бэкенд не запущен — демо-режим";
  }
  refreshRailStats();
}
async function refreshRailStats(){
  if(MOCK||!LAST_HEALTH){ $("#stDocs").textContent="0"; $("#stEnt").textContent="0"; $("#stRel").textContent="0";
    $("#docCountRail").textContent=""; $("#statusCorpus").textContent="Документов: 0 (демо-режим)"; return; }
  const c = LAST_HEALTH.corpus||{};
  $("#stDocs").textContent = c.documents||0;
  $("#stEnt").textContent = c.entities||0;
  $("#stRel").textContent = c.relations||0;
  $("#docCountRail").textContent = c.documents? "("+c.documents+")" : "";
  $("#statusCorpus").textContent = "Документов: "+(c.documents||0);
}

/* ---------------- view switching -------------------------------- */
function switchView(view){
  $$(".rail-item[data-view]").forEach(el=>el.classList.toggle("active", el.dataset.view===view));
  $$(".view").forEach(el=>el.classList.remove("active"));
  ({chat:"#viewChat", docs:"#viewDocs", dash:"#viewDash"})[view] && $(({chat:"#viewChat", docs:"#viewDocs", dash:"#viewDash"})[view]).classList.add("active");
  if(view==="docs") loadDocuments();
  if(view==="dash") loadDashboard();
}
$$(".rail-item[data-view]").forEach(el=>el.onclick=()=>switchView(el.dataset.view));

/* ---------------- geo filter (см. loadDocuments — фильтр живёт в панели
   «Документы» и работает по конкретной географии документов) ------------ */
let DOC_GEO_FILTER = "";  // "" = вся база; иначе — конкретная geo_label

/* ================================================================
   ЧАТЫ (мультивкладочность) — хранятся на сервере (общая БД), поэтому
   переживают обновление страницы и видны с любого устройства. В MOCK-режиме
   (без бэкенда) чат живёт только в памяти вкладки браузера — иначе некуда
   его сохранять; это единственный случай, когда персистентности нет.
   ================================================================ */
let chats = [];       // {id, title, panelEl, threadEl, msgCount}
let activeChatId = null;
let localSeq = 0;     // только для MOCK-режима (id без обращения к серверу)

function buildChatPanel(id, title){
  const panel = document.createElement("div");
  panel.className = "chat-panel";
  panel.id = "panel_"+id;
  panel.innerHTML = `
    <div class="onboard" id="onboard_${id}">
      <div class="onboard-card">
        <h1>👋 Начните здесь</h1>
        <p>Система отвечает СТРОГО по загруженным документам и ссылкам — не по общим знаниям модели.</p>
        <div class="onboard-steps">
          <div class="ostep"><div class="num">1</div><div><b>Загрузите документы</b><span>Вкладка «Документы» слева — файлы или ссылки</span></div></div>
          <div class="ostep"><div class="num">2</div><div><b>Задайте вопрос</b><span>Своими словами, на русском/английском/испанском</span></div></div>
          <div class="ostep"><div class="num">3</div><div><b>Получите ответ со ссылками</b><span>С указанием источников, дублирования и пробелов в знаниях</span></div></div>
        </div>
        <div class="onboard-actions">
          <button class="tbtn primary" data-goto-docs>Перейти к документам</button>
        </div>
      </div>
    </div>
    <div class="thread" id="thread_${id}" style="display:none"></div>
    <div class="composer">
      <div class="composer-inner">
        <textarea id="input_${id}" rows="2" placeholder="Например: какие есть данные по 3D-печати сталью 30ХГСА?"></textarea>
        <button class="tbtn send-btn" id="send_${id}">Отправить</button>
      </div>
      <div class="hint">Enter — отправить · Shift+Enter — перенос строки</div>
      <div class="chips" id="chips_${id}"></div>
    </div>`;
  $("#chatPanels").appendChild(panel);
  panel.querySelector("[data-goto-docs]").onclick = ()=>switchView("docs");

  const chat = {id, title, panelEl:panel, threadEl:panel.querySelector("#thread_"+id),
                onboardEl:panel.querySelector("#onboard_"+id), msgCount:0};
  chats.push(chat);

  const input = panel.querySelector("#input_"+id);
  const send = ()=>{ const v=input.value.trim(); if(!v) return; input.value=""; sendMessage(chat, v); };
  panel.querySelector("#send_"+id).onclick = send;
  input.addEventListener("keydown", e=>{ if(e.key==="Enter"&&!e.shiftKey){ e.preventDefault(); send(); } });

  renderSuggestChips(chat);
  return chat;
}
function renderSuggestChips(chat){
  const SUGGEST = ["какие есть данные по 3D-печати сталью 30ХГСА?","что известно про коррозионную стойкость?",
    "выщелачивание никеля в холодном климате","кучное выщелачивание меди в Чили"];
  $("#chips_"+chat.id).innerHTML = SUGGEST.map(s=>`<div class="chip" data-q="${escapeHtml(s)}">${escapeHtml(s)}</div>`).join("");
  $("#chips_"+chat.id).querySelectorAll(".chip").forEach(c=>c.onclick=()=>sendMessage(chat, c.dataset.q));
}

async function newChat(){
  let id, title;
  if(MOCK){
    localSeq++; id = "local-"+localSeq; title = "Чат "+localSeq;
  }else{
    try{
      const r = await api("/api/chats", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({})});
      id = r.id; title = r.title;
    }catch(e){
      alert("Не удалось создать чат: "+(e&&e.message?e.message:e));
      return null;
    }
  }
  const chat = buildChatPanel(id, title);
  switchView("chat");
  switchChat(id);
  renderChatTabs();
  return chat;
}
function switchChat(id){
  activeChatId = id;
  chats.forEach(c=>c.panelEl.classList.toggle("active", c.id===id));
  renderChatTabs();
}
async function closeChat(id){
  const idx = chats.findIndex(c=>c.id===id);
  if(idx<0) return;
  chats[idx].panelEl.remove();
  chats.splice(idx,1);
  if(!MOCK){
    try{ await fetch("/api/chats/"+encodeURIComponent(id), {method:"DELETE"}); }
    catch(e){ /* не критично — вкладка уже убрана локально */ }
  }
  if(chats.length===0){ await newChat(); return; }
  if(activeChatId===id) switchChat(chats[chats.length-1].id);
  renderChatTabs();
}
function renderChatTabs(){
  $("#chatTabs").innerHTML = chats.map(c=>`
    <div class="chat-tab ${c.id===activeChatId?'active':''}" data-id="${c.id}">
      <span class="tt">${escapeHtml(c.title)}</span>
      <span class="tx" data-close="${c.id}">×</span>
    </div>`).join("") + `<div class="chat-tab-new" id="btnAddChat">+</div>`;
  $("#chatTabs").querySelectorAll(".chat-tab").forEach(el=>{
    el.addEventListener("click", e=>{
      if(e.target.closest("[data-close]")){ e.stopPropagation(); closeChat(el.dataset.id); return; }
      switchChat(el.dataset.id);
    });
  });
  $("#btnAddChat").onclick = ()=>newChat();
}
$("#btnNewChat").onclick = ()=>newChat();

/* Восстановление ранее сохранённых чатов при загрузке страницы (общие для
   всех — не привязаны к конкретному браузеру) */
async function restoreChats(){
  if(MOCK){ await newChat(); return; }
  let list;
  try{ list = (await api("/api/chats")).chats||[]; }catch(e){ list=[]; }
  if(!list.length){ await newChat(); return; }
  for(const c of list){
    const chat = buildChatPanel(c.id, c.title);
    if(c.msg_count>0){
      chat.onboardEl.style.display="none";
      chat.threadEl.style.display="block";
      chat.msgCount = c.msg_count;
      try{
        const hist = (await api(`/api/chats/${encodeURIComponent(c.id)}/messages`)).messages||[];
        hist.forEach(m=>renderHistoryTurn(chat, m.query, m.result));
        chat.threadEl.scrollTop = chat.threadEl.scrollHeight;
      }catch(e){ /* история не критична для работы вкладки */ }
    }
  }
  switchChat(chats[chats.length-1].id);
  renderChatTabs();
}

/* Рендер уже сохранённого хода (вопрос+ответ) без индикатора "выполняется" —
   используется при восстановлении истории; свёрнутая трасса, чтобы не
   перегружать вид при возврате к старому чату. */
function renderHistoryTurn(chat, query, result){
  const userTurn = document.createElement("div");
  userTurn.className="turn turn-user";
  userTurn.innerHTML = `<div class="bubble">${escapeHtml(query)}</div>`;
  chat.threadEl.appendChild(userTurn);

  const aiTurn = document.createElement("div");
  aiTurn.className="turn";
  const trace = result.trace||[];
  aiTurn.innerHTML = `<div class="orch collapsed"><div class="orch-head"><b>⚙ Оркестратор</b><span class="summary">${trace.length} шагов · ${result.took_ms||0} мс</span></div>
    <div class="orch-body">${trace.map(t=>`<div class="ostep-row"><span class="tool">${escapeHtml(t.tool)}</span><span class="detail"><b>${escapeHtml(t.name)}</b> — ${escapeHtml(t.detail)}</span></div>`).join("")}</div></div>`;
  aiTurn.querySelector(".orch-head").onclick = ()=>aiTurn.querySelector(".orch").classList.toggle("collapsed");
  chat.threadEl.appendChild(aiTurn);
  const answerWrap = buildAnswer(result);
  aiTurn.appendChild(answerWrap);
  wireCitations(answerWrap);
}

/* ---------------- отправка сообщения и рендер ответа ------------ */
async function sendMessage(chat, query){
  chat.msgCount++;
  if(chat.msgCount===1){
    chat.onboardEl.style.display="none";
    chat.threadEl.style.display="block";
  }
  const userTurn = document.createElement("div");
  userTurn.className="turn turn-user";
  userTurn.innerHTML = `<div class="bubble">${escapeHtml(query)}</div>`;
  chat.threadEl.appendChild(userTurn);
  chat.threadEl.scrollTop = chat.threadEl.scrollHeight;

  const aiTurn = document.createElement("div");
  aiTurn.className="turn";
  aiTurn.innerHTML = `<div class="orch"><div class="orch-head"><b>⚙ Оркестратор</b><span class="summary">выполняется…</span></div><div class="orch-body"></div></div>`;
  chat.threadEl.appendChild(aiTurn);
  chat.threadEl.scrollTop = chat.threadEl.scrollHeight;

  let res;
  try{
    if(MOCK){ res = await mockChat(query); }
    else{ res = await api("/api/chat", {method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({query, chat_id: chat.id})}); }
  }catch(e){
    aiTurn.querySelector(".orch-head .summary").textContent = "ошибка";
    aiTurn.querySelector(".orch-body").innerHTML = `<div class="ostep-row"><span class="detail">${escapeHtml(e&&e.message?e.message:"Не удалось получить ответ от сервера.")}</span></div>`;
    return;
  }

  if(chat.msgCount===1){
    let title = query.trim(); title = title.length>28? title.slice(0,28)+"…" : title;
    chat.title = title || "Новый чат";
    renderChatTabs();
  }

  const trace = res.trace||[];
  const body = aiTurn.querySelector(".orch-body");
  body.innerHTML = trace.map(t=>`<div class="ostep-row"><span class="tool">${escapeHtml(t.tool)}</span><span class="detail"><b>${escapeHtml(t.name)}</b> — ${escapeHtml(t.detail)}</span></div>`).join("");
  aiTurn.querySelector(".orch-head .summary").textContent = trace.length+" шагов · "+(res.took_ms||0)+" мс";
  aiTurn.querySelector(".orch-head").onclick = ()=>aiTurn.querySelector(".orch").classList.toggle("collapsed");

  const answerWrap = buildAnswer(res);
  aiTurn.appendChild(answerWrap);
  wireCitations(answerWrap);
  chat.threadEl.scrollTop = chat.threadEl.scrollHeight;
}

function highlightTerms(text, terms){
  let html = escapeHtml(text);
  if(terms && terms.length){
    const parts = terms.map(t=> t.length>=4? t.slice(0, Math.max(4,t.length-2)) : t)
      .map(t=>t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"));
    if(parts.length){ html = html.replace(new RegExp("("+parts.join("|")+")","giu"), "<mark>$1</mark>"); }
  }
  return html;
}

function buildAnswer(res){
  const wrap = document.createElement("div");
  const ans = document.createElement("div"); ans.className="answer-box";
  ans.innerHTML = (res.answer.segments||[]).map(s=>`<p>${s.html}</p>`).join("") || "<p>Пусто.</p>";
  wrap.appendChild(ans);

  if(res.answer.why){
    const why = document.createElement("div"); why.className="why-box";
    why.innerHTML = `<span class="wi">💡 Почему так:</span><span>${escapeHtml(res.answer.why)}</span>`;
    wrap.appendChild(why);
  }

  if(res.dedup && res.dedup.length){
    const maxN = Math.max(1, ...res.dedup.map(d=>d.doc_count));
    const pg = document.createElement("div"); pg.className="panel-group";
    pg.innerHTML = `<div class="ph">🔁 Дублирование по источникам<span class="n">${res.dedup.length}</span></div>
      <div class="pb">${res.dedup.map(d=>`
        <div class="dedup-row"><span class="lbl" title="${escapeHtml(d.canonical)}">${escapeHtml(d.canonical)}</span>
          <div class="dedup-bar"><i style="width:${Math.round(d.doc_count/maxN*100)}%"></i></div>
          <span class="cnt">${d.doc_count} источник(ов)</span></div>`).join("")}</div>`;
    wrap.appendChild(pg);
  }

  if(res.evidence && res.evidence.length){
    const pg = document.createElement("div"); pg.className="panel-group";
    pg.innerHTML = `<div class="ph">📎 Источники<span class="n">${res.evidence.length}</span></div>
      <div class="pb">${res.evidence.map(ev=>{
        const v = ev.verification||{};
        const geoCls = v.geo_scope==="domestic"?"domestic":v.geo_scope==="foreign"?"foreign":"";
        const snip = highlightTerms(ev.snippet, ev.matched_terms);
        return `<div class="evi" id="${ev.id}">
          <div class="evi-top"><span class="tag">[${ev.id.replace('ev','')}]</span><b>${escapeHtml(ev.title)}</b><span class="id">${escapeHtml(ev.source_id)}</span></div>
          <div class="evi-snip">${snip}</div>
          <div class="evi-verify">
            <span class="vchip">📅 ${fmtDate(v.added_at)}</span>
            <span class="vchip">✓ достоверность ${fmtPct(v.confidence)}</span>
            ${v.geo_scope?`<span class="vchip ${geoCls}">${v.geo_scope==='domestic'?'отечественный':'зарубежный'}</span>`:''}
            ${v.lang?`<span class="vchip">${escapeHtml(v.lang)}</span>`:''}
          </div>
          ${ev.relevance?`<div class="evi-rel">${escapeHtml(ev.relevance)}</div>`:''}
        </div>`;}).join("")}</div>`;
    wrap.appendChild(pg);
  }

  const pg2 = document.createElement("div"); pg2.className="panel-group";
  const gaps = res.gaps||[];
  pg2.innerHTML = `<div class="ph">⚠ Пробелы в знаниях<span class="n">${gaps.length}</span></div>
    <div class="pb">${gaps.length? gaps.map(g=>`
      <div class="gap-item"><span class="gi">⚠</span><div><div class="note">${escapeHtml(g.note)}</div>
        ${g.have_individually?`<div class="haves">по отдельности встречается: ${Object.entries(g.have_individually).map(([k,v])=>`${escapeHtml(k)} — ${v}`).join(", ")}</div>`:''}
      </div></div>`).join("") : `<div class="gaps-empty">✓ По запрошенной комбинации пробелов не выявлено.</div>`}</div>`;
  wrap.appendChild(pg2);

  // экспорт в PDF — только когда есть реальные источники, т.е. ответ
  // действительно построен по документам (не пустой корпус/нет совпадений)
  if(res.evidence && res.evidence.length){
    const exportRow = document.createElement("div"); exportRow.className="answer-export-row";
    const btn = document.createElement("button");
    btn.className = "tbtn"; btn.type = "button";
    btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M3 1.5h5l3 3v7H3z" stroke="currentColor" stroke-width="1.2"/><path d="M8 1.5v3h3" stroke="currentColor" stroke-width="1.1"/></svg> Скачать отчёт PDF`;
    const payload = {query: res.query, answer: res.answer, evidence: res.evidence,
                     gaps: res.gaps||[], dedup: res.dedup||[]};
    btn.onclick = () => exportAnswerPdf(payload, btn);
    exportRow.appendChild(btn);
    wrap.appendChild(exportRow);
  }

  return wrap;
}
function wireCitations(scope){
  scope.querySelectorAll(".cite").forEach(c=>{
    c.onclick = ()=>{
      const el = scope.querySelector("#"+c.dataset.ev) || document.getElementById(c.dataset.ev);
      if(el){ el.scrollIntoView({behavior:"smooth", block:"center"}); el.classList.add("lit");
        setTimeout(()=>el.classList.remove("lit"), 1500); }
    };
  });
}

/* ================================================================
   PDF-ЭКСПОРТ — кнопка живёт при конкретном ответе в диалоге (buildAnswer),
   формируется уже после того, как ответ получен, и включает сам ответ,
   ссылки на источники и полные тексты документов (см. бэкенд).
   ================================================================ */
async function exportAnswerPdf(payload, btn){
  if(MOCK){ alert("Экспорт в PDF доступен при запущенном бэкенде."); return; }
  const old = btn.innerHTML; btn.textContent="Формирую…"; btn.disabled=true;
  try{
    const rep = await api("/api/report/pdf", {method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify(payload)});
    window.open(rep.url, "_blank");
  }catch(e){ alert("Не удалось сформировать отчёт: "+(e&&e.message?e.message:e)); }
  finally{ btn.innerHTML = old; btn.disabled=false; }
}

/* ================================================================
   ДОКУМЕНТЫ
   ================================================================ */
async function refreshIngestNote(){
  const el = $("#ingestNote");
  if(MOCK){ el.textContent="Демо-режим: загрузка и построение графа доступны при запущенном бэкенде."; return; }
  try{
    const h = LAST_HEALTH || await api("/api/health");
    el.innerHTML = `Поддерживаются: <b>${(h.ingest.supported_ext||[]).join(", ")}</b>. При загрузке строится граф: материал + процесс + условия + география + время — и добавляется в общую базу.`;
  }catch(e){ el.textContent="Не удалось получить список форматов."; }
}
let ALL_DOCS = [];  // последний загруженный список документов (для клиентской фильтрации)

async function loadDocuments(){
  await refreshIngestNote();
  let docs = [];
  if(!MOCK){ try{ docs = (await api("/api/documents")).documents||[]; }catch(e){ docs=[]; } }
  ALL_DOCS = docs;
  renderGeoFilterChips(docs);
  renderDocTable();
}
function renderGeoFilterChips(docs){
  // строим фильтр из РЕАЛЬНОЙ географии загруженных документов — не из
  // фиксированного списка стран; если выбранного значения больше нет
  // среди документов (например, документ удалили), сбрасываем на «Вся база»
  const labels = [...new Set(docs.map(d=>d.geo_label).filter(Boolean))].sort((a,b)=>a.localeCompare(b,"ru"));
  if(!labels.includes(DOC_GEO_FILTER)) DOC_GEO_FILTER = "";
  const seg = $("#geoSeg");
  seg.innerHTML = `<button data-geo="" class="${DOC_GEO_FILTER===""?"active":""}">Вся база</button>` +
    labels.map(l=>`<button data-geo="${escapeHtml(l)}" class="${DOC_GEO_FILTER===l?"active":""}">${escapeHtml(l)}</button>`).join("");
}
$("#geoSeg").addEventListener("click", e=>{
  const b = e.target.closest("button[data-geo]"); if(!b) return;
  DOC_GEO_FILTER = b.dataset.geo;
  $$("#geoSeg button").forEach(x=>x.classList.toggle("active", x===b));
  renderDocTable();
});
function renderDocTable(){
  const tbody = $("#docTableBody");
  const docs = DOC_GEO_FILTER ? ALL_DOCS.filter(d=>d.geo_label===DOC_GEO_FILTER) : ALL_DOCS;
  if(!ALL_DOCS.length){
    tbody.innerHTML = `<tr><td colspan="7"><div class="docs-empty">${MOCK?"Демо-режим — подключите бэкенд.":"Пока ничего не загружено. Перетащите файл выше или добавьте ссылку."}</div></td></tr>`;
    return;
  }
  if(!docs.length){
    tbody.innerHTML = `<tr><td colspan="7"><div class="docs-empty">По фильтру «${escapeHtml(DOC_GEO_FILTER)}» документов нет.</div></td></tr>`;
    return;
  }
  tbody.innerHTML = docs.map(d=>{
    const geoCls = d.geo_scope==="domestic"?"ok":d.geo_scope==="foreign"?"warn":"";
    const geo = d.geo_label? `<span class="badge ${geoCls}">${escapeHtml(d.geo_label)}</span>` : "—";
    const textBadge = d.has_text_layer? '<span class="badge ok">есть текст</span>':'<span class="badge warn">без текста</span>';
    return `<tr data-id="${escapeHtml(d.id)}">
      <td><span class="docname" data-open="${escapeHtml(d.id)}">${escapeHtml(d.title||d.id)}</span></td>
      <td>${escapeHtml(d.type||"—")} ${textBadge}</td>
      <td>${escapeHtml((d.lang||"—").toUpperCase())}</td>
      <td>${geo}</td>
      <td>${fmtPct(d.confidence)}</td>
      <td>${fmtDate(d.added_at)}</td>
      <td><button class="rowbtn" data-dl="${escapeHtml(d.id)}">Скачать</button><button class="rowbtn" data-del="${escapeHtml(d.id)}">Удалить</button></td>
    </tr>`;
  }).join("");
}
$("#docTableBody").addEventListener("click", e=>{
  const open = e.target.closest("[data-open]"); if(open){ openDocument(open.dataset.open); return; }
  const dl = e.target.closest("[data-dl]"); if(dl){ downloadDocument(dl.dataset.dl); return; }
  const del = e.target.closest("[data-del]"); if(del){ if(confirm("Удалить документ безвозвратно?")) deleteDocument(del.dataset.del); return; }
});

function downloadDocument(id){
  if(MOCK) return;
  window.open("/api/documents/"+encodeURIComponent(id)+"/download", "_blank");
}
async function deleteDocument(id){
  if(MOCK) return;
  try{
    const r = await fetch("/api/documents/"+encodeURIComponent(id), {method:"DELETE"}).then(r=>r.json());
    if(!r.ok) throw new Error();
    closeDocViewer();
    await loadDocuments();
    LAST_HEALTH = await api("/api/health").catch(()=>LAST_HEALTH);
    refreshRailStats();
  }catch(e){ alert("Не удалось удалить документ."); }
}
async function openDocument(id){
  const el = $("#docViewer"); el.classList.add("open");
  $("#dvTitle").textContent="Загрузка…"; $("#dvMeta").textContent=""; $("#dvBody").textContent="";
  el.dataset.docId = id;
  if(MOCK){ $("#dvTitle").textContent="Недоступно в демо-режиме"; return; }
  let doc; try{ doc = await api("/api/documents/"+encodeURIComponent(id)); }catch(e){ doc=null; }
  if(!doc){ $("#dvTitle").textContent="Документ не найден"; return; }
  $("#dvTitle").textContent = doc.title||doc.id;
  const bits = [doc.type||"Документ", doc.id, "язык: "+(doc.lang||"—"), "достоверность: "+fmtPct(doc.confidence)];
  if(doc.geo_scope) bits.push(doc.geo_scope==="domestic"?"отечественная практика":"зарубежная практика");
  if(doc.source) bits.push(doc.source);
  $("#dvMeta").textContent = bits.join(" · ");
  $("#dvBody").textContent = doc.text&&doc.text.trim()? doc.text : "(текст не извлечён)";
}
function closeDocViewer(){ $("#docViewer").classList.remove("open"); }
$("#dvClose").onclick = closeDocViewer;
$("#docViewer").addEventListener("click", e=>{ if(e.target.id==="docViewer") closeDocViewer(); });
$("#dvDownload").onclick = ()=>{ const id=$("#docViewer").dataset.docId; if(id) downloadDocument(id); };
$("#dvDelete").onclick = ()=>{ const id=$("#docViewer").dataset.docId; if(id && confirm("Удалить документ безвозвратно?")) deleteDocument(id); };

function uploadCard(name){
  const el = document.createElement("div"); el.className="up-card";
  el.innerHTML = `<div class="uc-head"><span class="uc-name"></span><span class="badge" data-st>анализ…</span></div><div class="uc-body" data-body></div>`;
  el.querySelector(".uc-name").textContent=name;
  $("#upResults").prepend(el); return el;
}
function renderUpload(card, res){
  const st = card.querySelector("[data-st]"), body = card.querySelector("[data-body]");
  const d = res.detect||{};

  if(res.status==="archive"){
    st.className="badge ok"; st.textContent=`архив: ${res.stored}/${res.total}`;
    body.innerHTML = `<div class="uc-row"><span class="k">Обработано файлов</span><span>${res.total}, сохранено: ${res.stored}</span></div>` +
      (res.results||[]).map(r=>{
        const ok = r.status==="stored"||r.status==="stored_no_text";
        const cls = ok? (r.status==="stored"?"ok":"warn") : "warn";
        const label = ok? (r.status==="stored"?"сохранён":"без текста") : (r.status==="error"?"ошибка":"пропущен");
        return `<div class="uc-row"><span class="k" style="min-width:0;flex:1">${escapeHtml(r.filename)}</span>
          <span class="badge ${cls}">${label}</span></div>` +
          (r.message?`<div class="uc-row"><span class="k"></span><span style="color:var(--text-dim)">${escapeHtml(r.message)}</span></div>`:"");
      }).join("");
    return;
  }

  const rows = [`<div class="uc-row"><span class="k">Тип</span><span>${escapeHtml(d.kind||"—")}${d.pages?` · ${d.pages} стр.`:""}</span></div>`,
                `<div class="uc-row"><span class="k">Определение</span><span>${escapeHtml(d.reason||"")}</span></div>`];
  let extra="";
  if(res.status==="stored"||res.status==="stored_no_text"){
    st.className = res.status==="stored"?"badge ok":"badge warn"; st.textContent = res.status==="stored"?"сохранён":"без текста";
    rows.push(`<div class="uc-row"><span class="k">Документ</span><span>${escapeHtml(res.document.id)} · ${res.document.chars} симв.</span></div>`);
    if(res.graph){
      const g = res.graph;
      const chips = [...g.materials, ...g.processes, ...g.equipment, ...g.geography, ...g.time, ...g.team]
        .map(x=>`<span class="gchip">${escapeHtml(x)}</span>`).join("");
      extra += `<div class="uc-row"><span class="k">Граф</span><span>${g.relations} связей, ${g.constraints} числовых условий${g.llm_used?" · LLM-извлечение":""}</span></div>`;
      if(g.error) extra += `<div class="uc-row"><span class="k">⚠ Граф</span><span style="color:var(--warn)">не удалось построить: ${escapeHtml(g.error)} (текст документа всё равно сохранён)</span></div>`;
      if(chips) extra += `<div class="uc-graph">${chips}</div>`;
    }
  }else if(res.status==="unsupported"||res.status==="error"){
    st.className="badge warn"; st.textContent="ошибка";
    extra += `<div class="uc-row"><span class="k">Причина</span><span>${escapeHtml(res.message||"неизвестная ошибка")}</span></div>`;
  }else{
    st.className="badge"; st.textContent="демо"; rows.push(`<div class="uc-row"><span class="k">Статус</span><span>${escapeHtml(res.note||"")}</span></div>`);
  }
  body.innerHTML = rows.join("")+extra;
}

/* Единая обёртка для запросов загрузки: НИКОГДА не глотает реальную причину
   сбоя — если сервер ответил (даже 4xx/5xx), показываем его сообщение;
   если запрос вообще не дошёл (недоступен бэкенд, CORS, файл:// и т.п.) —
   показываем текст исключения браузера, а не общую фразу «сетевая ошибка». */
async function postForUpload(url, opts){
  let resp;
  try{
    resp = await fetch(url, opts);
  }catch(e){
    return {status:"error", detect:{},
      message:"запрос не дошёл до сервера: "+(e && e.message ? e.message : e)+
              ". Проверьте, что бэкенд запущен и открыт по этому же адресу (не как локальный файл)."};
  }
  let body;
  try{ body = await resp.json(); }
  catch(e){
    return {status:"error", detect:{},
      message:`сервер ответил кодом ${resp.status} (${resp.statusText||"без описания"}), но не JSON — `+
              "возможно, файл слишком большой для прокси/хостинга."};
  }
  if(!resp.ok && !body.status){
    return {status:"error", detect:{}, message: body.message || body.detail || `ошибка сервера (${resp.status})`};
  }
  return body;
}

async function handleFiles(files){
  switchView("docs");
  for(const f of files){
    const card = uploadCard(f.name);
    let res;
    if(MOCK){ await sleep(250); res={status:"mock", note:"загрузка доступна при запущенном бэкенде", detect:{kind:"?",reason:"—"}}; }
    else{ const fd=new FormData(); fd.append("file", f); res = await postForUpload("/api/upload", {method:"POST", body:fd}); }
    renderUpload(card, res);
  }
  if(!MOCK){ await loadDocuments(); LAST_HEALTH = await api("/api/health").catch(()=>LAST_HEALTH); refreshRailStats(); }
}
(function wireDropzone(){
  const dz=$("#dropzone"), fi=$("#fileInput");
  dz.onclick=()=>fi.click();
  fi.onchange=()=>{ if(fi.files.length) handleFiles([...fi.files]); fi.value=""; };
  ["dragenter","dragover"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.add("drag");}));
  ["dragleave","drop"].forEach(ev=>dz.addEventListener(ev,e=>{e.preventDefault();dz.classList.remove("drag");}));
  dz.addEventListener("drop", e=>{ if(e.dataTransfer.files.length) handleFiles([...e.dataTransfer.files]); });
})();
async function handleUrl(url){
  url=(url||"").trim(); if(!url) return;
  switchView("docs");
  const card = uploadCard(url);
  let res;
  if(MOCK){ await sleep(300); res={status:"mock", note:"загрузка ссылок доступна при запущенном бэкенде", detect:{kind:"?",reason:"—"}}; }
  else{ res = await postForUpload("/api/upload_url", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({url})}); }
  renderUpload(card, res);
  if(!MOCK){ await loadDocuments(); LAST_HEALTH = await api("/api/health").catch(()=>LAST_HEALTH); refreshRailStats(); }
}
$("#urlAdd").onclick = ()=>{ const v=$("#urlInput").value; $("#urlInput").value=""; handleUrl(v); };
$("#urlInput").addEventListener("keydown", e=>{ if(e.key==="Enter"){ e.preventDefault(); $("#urlAdd").click(); } });

/* ================================================================
   ДАШБОРД
   ================================================================ */
async function loadDashboard(){
  const el = $("#dashView");
  if(MOCK){ el.innerHTML = `<div class="dash-empty">Дашборд требует бэкенда — здесь считается реальная статистика по загруженным документам.</div>`; return; }
  let data; try{ data = await api("/api/dashboard"); }catch(e){ el.innerHTML=`<div class="dash-empty">Ошибка загрузки дашборда: ${escapeHtml(e&&e.message?e.message:String(e))}</div>`; return; }
  renderDashboard(data);
}
function renderDashboard(data){
  const el = $("#dashView");
  if(!data.computed_at){
    el.innerHTML = `<div class="dash-head"><div class="dash-stale">Дашборд ещё не рассчитан. Данные строятся суммаризацией LLM и не обновляются автоматически.</div>
      <button class="tbtn primary" id="btnRefreshDash">Обновить дашборд</button></div>
      <div class="dash-empty">Нажмите «Обновить дашборд», чтобы построить сводку по текущим ${data.current_documents||0} документам.</div>`;
    $("#btnRefreshDash").onclick = refreshDashboard;
    return;
  }
  const maxCov = Math.max(1, ...data.coverage.map(c=>c.doc_count));
  el.innerHTML = `
    <div class="dash-head">
      ${data.is_stale? `<div class="dash-stale">Данные изменились с последнего расчёта (сейчас документов: ${data.current_documents}). Нажмите «Обновить», чтобы пересчитать.</div>`:
        `<div class="dash-stale" style="background:#d8ecd8;border-color:var(--ok)">Актуально.</div>`}
      <button class="tbtn primary" id="btnRefreshDash">🔄 Обновить дашборд</button>
    </div>
    <div class="dash-grid">
      <div class="dash-summary">${escapeHtml(data.summary||"")}</div>
      <div class="groupbox"><div class="gh">Покрытие по направлениям</div>
        <div class="gb">${data.coverage.map(c=>`
          <div class="cov-row"><span class="lbl">${escapeHtml(c.direction)}</span>
            <div class="cov-bar"><i style="width:${Math.round(c.doc_count/maxCov*100)}%"></i></div>
            <span style="width:70px;text-align:right;font-family:var(--mono)">${c.doc_count}</span></div>`).join("")}</div></div>
      <div class="groupbox"><div class="gh">Активность команд/лабораторий</div>
        <div class="gb">${data.teams.length? data.teams.map(t=>`<div class="team-row"><span>${escapeHtml(t.label)}</span><span>${t.doc_count} документ(ов)</span></div>`).join("") :
          '<div style="color:var(--text-dim);font-size:11.5px">Команды/лаборатории не упомянуты в документах явно.</div>'}</div></div>
      <div class="groupbox" style="grid-column:1/-1"><div class="gh">Зоны риска</div>
        <div class="gb">${data.risk_zones.length? data.risk_zones.map(r=>`<div class="risk-item"><span class="ri">⚠</span><span>${escapeHtml(r.note)}</span></div>`).join("") :
          '<div style="color:var(--ok);font-size:11.5px">Явных зон риска не выявлено.</div>'}</div></div>
    </div>`;
  $("#btnRefreshDash").onclick = refreshDashboard;
}
async function refreshDashboard(){
  const btn = $("#btnRefreshDash"); if(btn){ btn.textContent="Считаю…"; btn.disabled=true; }
  try{ const data = await api("/api/dashboard/refresh", {method:"POST"}); renderDashboard(data); }
  catch(e){ alert("Не удалось обновить дашборд: "+(e&&e.message?e.message:e)); if(btn){ btn.textContent="🔄 Обновить дашборд"; btn.disabled=false; } }
}

/* ================================================================
   MOCK (без бэкенда) — честный, без имитации графа/дедупа/пробелов
   ================================================================ */
async function mockChat(query){
  await sleep(300);
  return {
    query, trace:[{kind:"plan",tool:"orchestrator",name:"Демо-режим",detail:"бэкенд не подключён"}],
    answer:{segments:[{html:escapeHtml("Это демо-режим без бэкенда. Поиск по документам, граф знаний, "+
      "дедупликация источников и пробелы знаний считаются на сервере — запустите backend (см. README), "+
      "чтобы получить настоящий ответ по вашим документам.")}], why:""},
    evidence:[], entities:[], gaps:[], dedup:[], took_ms:0
  };
}

/* ---------------- init ------------------------------------------- */
detectBackend().then(restoreChats);
